<?php

ob_start();
 
date_Default_timezone_set('Asia/Tashkent');

define('Umidjon', "8646531044:AAFZzHTWC49yU22H9JCwCgyneqUdzwJdSQY");

$bot = bot('getMe', ['bot'])->result->username;
$idbot = bot('getMe', ['bot'])->result->id;
$sana = date("d.m.Y");
$soat = date("H:i");
$time = $soat;
$checkcard_shop_id = "322s959";  // @CheckCardUz_bot dan oling
$checkcard_api_key = "A7H7sPJC5K5";  // @CheckCardUz_bot dan oling

$umidjon = '8302721751';
$devid = '8302721751';

$rek = "🛠 <b>Bot dasturchisi @stazgohelp</b>";

define("DB_SERVER", "localhost");
define("DB_USERNAME", "6a115dcd3ddcc_stazgobot");
define("DB_PASSWORD", "123456");
define("DB_NAME", "6a115dcd3ddcc_stazgobot");

$connect = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
mysqli_set_charset($connect, 'utf8mb4');


// ========== BUG LOG VA XAVFSIZLIK YORDAMCHILARI ==========
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/bug_log.txt');

function bug_log($title, $context = []) {
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $title;
    if (!empty($context)) {
        $line .= ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    error_log($line);
}

function clean_username($value) {
    $value = trim((string)$value);
    $value = ltrim($value, '@');
    return preg_match('/^[A-Za-z0-9_]{5,32}$/', $value) ? $value : '';
}

function money_fmt($sum) {
    return number_format((int)$sum, 0, '.', ' ');
}

function order_lock($type, $id) {
    $dir = __DIR__ . '/caches';
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    $file = $dir . '/lock_' . preg_replace('/[^a-z0-9_\-]/i', '', $type . '_' . $id) . '.lock';
    if (file_exists($file) && (time() - filemtime($file)) < 120) return false;
    file_put_contents($file, time());
    return true;
}

function order_unlock($type, $id) {
    $file = __DIR__ . '/caches/lock_' . preg_replace('/[^a-z0-9_\-]/i', '', $type . '_' . $id) . '.lock';
    if (file_exists($file)) @unlink($file);
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function db_add_column_if_missing($connect, $table, $column, $definition) {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $column = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $check = mysqli_query($connect, "SHOW COLUMNS FROM `$table` LIKE '$column'");
    if ($check && mysqli_num_rows($check) == 0) {
        mysqli_query($connect, "ALTER TABLE `$table` ADD `$column` $definition");
    }
}

function sql_escape($value) {
    global $connect;
    return mysqli_real_escape_string($connect, (string)$value);
}

function get_admin_ids() {
    global $connect, $admin;
    $ids = [];
    $result = mysqli_query($connect, "SELECT user_id FROM admins");
    while ($row = mysqli_fetch_assoc($result)) {
        if (!empty($row['user_id'])) $ids[] = trim($row['user_id']);
    }
    if (!empty($admin)) $ids[] = trim((string)$admin);
    return array_values(array_unique(array_filter($ids)));
}

function get_active_manual_card() {
    global $connect;
    $result = mysqli_query($connect, "SELECT * FROM manual_payment_cards WHERE status = 'active' ORDER BY id DESC LIMIT 1");
    return $result ? mysqli_fetch_assoc($result) : null;
}

function get_manual_card($id) {
    global $connect;
    $id = (int)$id;
    $result = mysqli_query($connect, "SELECT * FROM manual_payment_cards WHERE id = '$id' LIMIT 1");
    return $result ? mysqli_fetch_assoc($result) : null;
}

function get_manual_payment($id) {
    global $connect;
    $id = (int)$id;
    $result = mysqli_query($connect, "SELECT * FROM manual_payments WHERE id = '$id' LIMIT 1");
    return $result ? mysqli_fetch_assoc($result) : null;
}

function manual_payment_status_text($status) {
    $map = [
        'pending' => 'To‘lov kutilmoqda',
        'review' => 'Admin tekshiruvda',
        'approved' => 'Tasdiqlandi',
        'rejected' => 'Rad etildi',
        'cancelled' => 'Bekor qilindi'
    ];
    return $map[$status] ?? $status;
}

function manual_payment_admin_text($payment, $card, $statusTitle = '🧾 Yangi ruchnoy to‘lov') {
    $amount = money_fmt($payment['amount']);
    $userName = h(getName($payment['user_id']));
    $cardNumber = h($card['card_number'] ?? 'Noma’lum');
    $owner = h($card['owner'] ?? 'Noma’lum');
    $note = trim((string)($card['note'] ?? ''));
    $noteText = $note !== '' ? "\n<b>Izoh:</b> " . h($note) : '';
    $status = manual_payment_status_text($payment['status']);
    return "<b>$statusTitle</b>\n\n" .
        "<b>To‘lov ID:</b> <code>{$payment['id']}</code>\n" .
        "<b>Foydalanuvchi:</b> <a href='tg://user?id={$payment['user_id']}'>$userName</a>\n" .
        "<b>User ID:</b> <code>{$payment['user_id']}</code>\n" .
        "<b>Summa:</b> <code>$amount so‘m</code>\n" .
        "<b>Karta:</b> <code>$cardNumber</code>\n" .
        "<b>Karta egasi:</b> $owner$noteText\n" .
        "<b>Status:</b> $status\n" .
        "<b>Sana:</b> {$payment['created_at']}";
}

function update_manual_admin_messages($payment, $statusTitle) {
    $card = get_manual_card($payment['card_id']);
    $messages = json_decode($payment['admin_messages'] ?? '[]', true);
    if (!is_array($messages)) $messages = [];
    $text = manual_payment_admin_text($payment, $card, $statusTitle);
    foreach ($messages as $msg) {
        if (empty($msg['chat_id']) || empty($msg['message_id'])) continue;
        bot('editMessageText', [
            'chat_id' => $msg['chat_id'],
            'message_id' => $msg['message_id'],
            'text' => $text,
            'parse_mode' => 'html',
            'disable_web_page_preview' => true
        ]);
    }
}

function send_manual_payment_to_admins($payment_id) {
    global $connect;
    $payment = get_manual_payment($payment_id);
    if (!$payment) return false;
    $card = get_manual_card($payment['card_id']);
    $admins = get_admin_ids();
    $savedMessages = [];
    $keyboard = json_encode(['inline_keyboard' => [
        [
            ['text' => '✅ Tasdiqlash', 'callback_data' => 'manual_approve=' . $payment['id']],
            ['text' => '❌ Rad etish', 'callback_data' => 'manual_reject=' . $payment['id']]
        ],
        [['text' => '👤 Foydalanuvchi', 'callback_data' => 'checkid=' . $payment['user_id']]]
    ]], JSON_UNESCAPED_UNICODE);
    foreach ($admins as $adminId) {
        $msg = bot('sendMessage', [
            'chat_id' => $adminId,
            'text' => manual_payment_admin_text($payment, $card),
            'parse_mode' => 'html',
            'disable_web_page_preview' => true,
            'reply_markup' => $keyboard
        ]);
        if ($msg && isset($msg->ok) && $msg->ok && isset($msg->result->message_id)) {
            $savedMessages[] = ['chat_id' => (string)$adminId, 'message_id' => $msg->result->message_id];
        }
        bot('copyMessage', [
            'chat_id' => $adminId,
            'from_chat_id' => $payment['proof_chat_id'],
            'message_id' => $payment['proof_message_id']
        ]);
    }
    $messagesJson = sql_escape(json_encode($savedMessages, JSON_UNESCAPED_UNICODE));
    mysqli_query($connect, "UPDATE manual_payments SET admin_messages = '$messagesJson' WHERE id = '{$payment['id']}'");
    return true;
}

function temp_json_path($name, $user_id) {
    if (!is_dir("caches")) @mkdir("caches", 0777, true);
    $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '', $name . '_' . $user_id);
    return "caches/$safe.json";
}

function save_temp_json($name, $user_id, $data) {
    file_put_contents(temp_json_path($name, $user_id), json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function load_temp_json($name, $user_id) {
    $file = temp_json_path($name, $user_id);
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function clear_temp_json($name, $user_id) {
    $file = temp_json_path($name, $user_id);
    if (file_exists($file)) @unlink($file);
}

function resolve_gift_receiver($input, $current_id, $current_username = '') {
    $raw = trim((string)$input);
    $lower = mb_strtolower($raw, 'UTF-8');
    if (in_array($lower, ["o'zimga", "ozimga", "o‘zimga", "oʻzimga", "uzimga"], true)) {
        return ['receiver_id' => (string)$current_id, 'receiver_username' => $current_username ? '@' . ltrim($current_username, '@') : (string)$current_id];
    }
    if (ctype_digit($raw)) {
        return ['receiver_id' => $raw, 'receiver_username' => $raw];
    }
    $username = clean_username($raw);
    if ($username !== '') {
        $knownId = resolve_known_user_id_by_username($username);
        return ['receiver_id' => $knownId, 'receiver_username' => '@' . $username];
    }
    return null;
}

function build_gift_text($style, $comment, $sender_name) {
    $comment = trim((string)$comment);
    $sender_name = trim((string)$sender_name);
    if ($style === 'open') {
        $text = ($sender_name !== '' ? $sender_name : 'Foydalanuvchi') . " sizga gift yubordi.";
    } else {
        $text = "Sizga anonim gift yuborildi.";
    }
    if ($comment !== '') {
        $text .= "\n" . $comment;
    }
    return mb_substr($text, 0, 128, 'UTF-8');
}

function send_gift_by_bot($gift, $receiver_id, $receiver_username, $style, $comment, $sender_name) {
    $receiver_id = trim((string)$receiver_id);
    $receiver_username = trim((string)$receiver_username);
    if ($receiver_id === '' && $receiver_username !== '') {
        $chat = bot('getChat', ['chat_id' => $receiver_username]);
        if ($chat && isset($chat->ok) && $chat->ok && isset($chat->result->id)) {
            $receiver_id = (string)$chat->result->id;
        }
    }
    $payload = [
        'gift_id' => $gift['gift_id'],
        'text' => build_gift_text($style, $comment, $sender_name)
    ];
    if ($receiver_id !== '') {
        $payload['user_id'] = $receiver_id;
    } elseif ($receiver_username !== '') {
        $payload['chat_id'] = $receiver_username;
    } else {
        return ['ok' => false, 'error' => 'Qabul qiluvchi topilmadi'];
    }
    $result = bot('sendGift', $payload);
    if ($result && isset($result->ok) && $result->ok) {
        return ['ok' => true];
    }
    return ['ok' => false, 'error' => $result->description ?? "Gift yuborishda noma'lum xatolik"];
}

function get_bot_star_balance_amount() {
    $result = bot('getMyStarBalance', []);
    if ($result && isset($result->ok) && $result->ok && isset($result->result->amount)) {
        return (int)$result->result->amount;
    }
    return null;
}

function get_available_gifts_list() {
    $result = bot('getAvailableGifts', []);
    if (!$result || !isset($result->ok) || !$result->ok || empty($result->result->gifts)) {
        return [];
    }
    return $result->result->gifts;
}

function find_available_gift_by_id($gift_id) {
    $gift_id = trim((string)$gift_id);
    foreach (get_available_gifts_list() as $gift) {
        if ((string)($gift->id ?? '') === $gift_id) {
            return $gift;
        }
    }
    return null;
}

function gift_cost_from_available($gift) {
    if (!$gift) return null;
    if (isset($gift->star_count)) return (int)$gift->star_count;
    if (isset($gift->total_count)) return (int)$gift->total_count;
    return null;
}

function resolve_known_user_id_by_username($username) {
    global $connect;
    $username = clean_username($username);
    if ($username === '') return '';
    $safe = sql_escape(mb_strtolower($username, 'UTF-8'));
    $result = mysqli_query($connect, "SELECT user_id FROM users WHERE LOWER(username) = '$safe' ORDER BY id DESC LIMIT 1");
    $row = $result ? mysqli_fetch_assoc($result) : null;
    return $row['user_id'] ?? '';
}
// ========== BUG LOG VA XAVFSIZLIK YORDAMCHILARI TUGADI ==========

// ========== FRAGMENT-UZ API CLASS ==========
class FragmentUzAPI
{
    private string $apiKey;
    private string $baseUrl;
    private ?string $lastError = null;

    public function __construct(string $apiKey, string $baseUrl = 'https://fragment-api.uz/api/v1')
    {
        $this->apiKey = $apiKey;
        $this->baseUrl = $baseUrl;
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    private function request(string $endpoint, array $data = []): ?array
    {
        $url = $this->baseUrl . $endpoint;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-API-Key: ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            $this->lastError = "CURL xatosi: " . $curlError;
            if (function_exists('bug_log')) bug_log('Fragment CURL error', ['endpoint' => $endpoint, 'error' => $curlError]);
            return null;
        }

        $result = json_decode($response, true);

        if ($httpCode >= 400) {
            $this->lastError = $result['message'] ?? "HTTP xatosi: $httpCode";
            if (function_exists('bug_log')) bug_log('Fragment HTTP error', ['endpoint' => $endpoint, 'http' => $httpCode, 'response' => $response]);
            return null;
        }

        if (!isset($result['ok'])) {
            $this->lastError = "Noto'g'ri javob formati";
            return null;
        }

        if ($result['ok'] !== true) {
            $this->lastError = $result['message'] ?? "Noma'lum xatolik";
            return null;
        }

        return $result;
    }

    /**
     * Telegram Stars sotib olish (AVTOMATIK - tasdiqlash kerak emas!)
     */
    public function buyStars(string $username, int $amount): ?array
    {
        $result = $this->request('/stars/buy', [
            'username' => ltrim($username, '@'),
            'amount' => $amount
        ]);
        return $result['result'] ?? null;
    }

    /**
     * Telegram Premium sotib olish (AVTOMATIK - tasdiqlash kerak emas!)
     */
    public function buyPremium(string $username, int $duration): ?array
    {
        $result = $this->request('/premium/buy', [
            'username' => ltrim($username, '@'),
            'duration' => $duration
        ]);
        return $result['result'] ?? null;
    }

    /**
     * Telegram foydalanuvchi Fragment orqali topilishini tekshirish
     */
    public function getInfo(string $username): ?array
    {
        $result = $this->request('/getInfo', [
            'username' => ltrim($username, '@')
        ]);
        return $result['result'] ?? null;
    }

    /**
     * Stars narxini Fragment API orqali tekshirish
     */
    public function getStarsPricing(int $amount): ?array
    {
        $result = $this->request('/stars/pricing', [
            'amount' => $amount
        ]);
        return $result['result'] ?? null;
    }

    /**
     * Premium paketlari narxini Fragment API orqali tekshirish
     */
    public function getPremiumPricing(): ?array
    {
        $result = $this->request('/premium/pricing', []);
        return $result['result'] ?? null;
    }

    /**
     * Loyiha hamyoni balansini olish
     */
    public function getWalletBalance(): ?array
    {
        $result = $this->request('/wallet/balance', []);
        return $result['result'] ?? null;
    }

    /**
     * Hamyon imkoniyatlarini hisoblash
     */
    public function walletCalculate(): ?array
    {
        $result = $this->request('/wallet/calculate', []);
        return $result['result'] ?? null;
    }
}
// ========== FRAGMENT-UZ API CLASS TUGADI ==========

// ========== NOMER OLISH API FUNKSIYALARI ==========
function formatCountries($countriesData)
{
    $countryList = [];
    $simfoiz = @file_get_contents("set/raqam_foiz.txt") / 100 ?: 0.2;
    foreach ($countriesData as $code => $price) {
        $countryInfo = getCountryInfo($code);
        $finalPrice = $price * (1 + $simfoiz);

        $countryList[] = [
            'country_code' => $code,
            'price_uzs' => $price,
            'final_price' => $finalPrice,
            'country_name' => $countryInfo['name'],
            'flag' => $countryInfo['flag']
        ];
    }
    return $countryList;
}

function buildCountriesKeyboard($countries, $page, $total, $perPage)
{
    $buttons = [];
    foreach ($countries as $country) {
        $buttonText = $country['flag'] . " " . $country['country_name'] . " - " . $country['final_price'] . " so'm";
        $buttons[] = [['text' => $buttonText, 'callback_data' => "get_number={$country['final_price']}={$country['country_code']}={$country['country_name']}"]];
    }

    $keyboard = $buttons;
    $keyboard[] = [['icon_custom_emoji_id' => "5269490165667089699",'text' => " TOP 10", 'callback_data' => "top10"], ['icon_custom_emoji_id' => "5458646267754201082",'text' => " Arzon", 'callback_data' => "cheap"]];
    $keyboard[] = [['icon_custom_emoji_id' => "5440715101415956697",'text' => " Sotib olgan raqamlarim", 'callback_data' => "raqamlarim"]];

    $nav = [];
    if ($page > 0) {
        $nav[] = ['icon_custom_emoji_id' => "5271599436991052462",'text' => " Oldingi", 'callback_data' => "allcountries22=$page=prev"];
    }
    if (($page * $perPage + $perPage) < $total) {
        $nav[] = ['icon_custom_emoji_id' => "5269765713588930349",'text' => " Keyingi", 'callback_data' => "allcountries22=$page=next"];
    }
    if (!empty($nav)) {
        $keyboard[] = $nav;
    }

    return json_encode(['inline_keyboard' => $keyboard], JSON_UNESCAPED_UNICODE);
}

function buildTopCheapKeyboard($countries, $type)
{
    $keyboard = [];
    foreach ($countries as $country) {
        $buttonText = $country['flag'] . " " . $country['country_name'] . " - " . $country['final_price'] . " so'm";
        $keyboard[] = [['text' => $buttonText, 'callback_data' => "get_number={$country['final_price']}={$country['country_code']}={$country['country_name']}"]];
    }
    $keyboard[] = [['icon_custom_emoji_id' => "5278702045883292456",'text' => " Orqaga", 'callback_data' => "allcountries22=0=none"]];
    return json_encode(['inline_keyboard' => $keyboard], JSON_UNESCAPED_UNICODE);
}

function getCountryInfo($code)
{
    $countries = [
        'UZ' => ['flag' => '🇺🇿', 'name' => 'Oʻzbekiston'],
        'RU' => ['flag' => '🇷🇺', 'name' => 'Rossiya'],
        'KZ' => ['flag' => '🇰🇿', 'name' => 'Qozogʻiston'],
        'KG' => ['flag' => '🇰🇬', 'name' => 'Qirgʻiziston'],
        'VE' => ['flag' => '🇻🇪', 'name' => 'Venesuela'],
        'HK' => ['flag' => '🇭🇰', 'name' => 'Gonkong'],
        'AF' => ['flag' => '🇦🇫', 'name' => 'Afgʻoniston'],
        'GT' => ['flag' => '🇬🇹', 'name' => 'Gvatemala'],
        'US' => ['flag' => '🇺🇸', 'name' => 'AQSH'],
        'GB' => ['flag' => '🇬🇧', 'name' => 'Buyuk Britaniya'],
        'DE' => ['flag' => '🇩🇪', 'name' => 'Germaniya'],
        'FR' => ['flag' => '🇫🇷', 'name' => 'Fransiya'],
        'IT' => ['flag' => '🇮🇹', 'name' => 'Italiya'],
        'ES' => ['flag' => '🇪🇸', 'name' => 'Ispaniya'],
        'TR' => ['flag' => '🇹🇷', 'name' => 'Turkiya'],
        'CN' => ['flag' => '🇨🇳', 'name' => 'Xitoy'],
        'JP' => ['flag' => '🇯🇵', 'name' => 'Yaponiya'],
        'KR' => ['flag' => '🇰🇷', 'name' => 'Janubiy Koreya'],
        'IN' => ['flag' => '🇮🇳', 'name' => 'Hindiston'],
        'BR' => ['flag' => '🇧🇷', 'name' => 'Braziliya'],
        'CA' => ['flag' => '🇨🇦', 'name' => 'Kanada'],
        'AU' => ['flag' => '🇦🇺', 'name' => 'Avstraliya'],
        'UA' => ['flag' => '🇺🇦', 'name' => 'Ukraina'],
        'PL' => ['flag' => '🇵🇱', 'name' => 'Polsha'],
        'NL' => ['flag' => '🇳🇱', 'name' => 'Niderlandiya'],
        'SE' => ['flag' => '🇸🇪', 'name' => 'Shvetsiya'],
        'NO' => ['flag' => '🇳🇴', 'name' => 'Norvegiya'],
        'FI' => ['flag' => '🇫🇮', 'name' => 'Finlandiya'],
        'DK' => ['flag' => '🇩🇰', 'name' => 'Daniya'],
        'CZ' => ['flag' => '🇨🇿', 'name' => 'Chexiya'],
        'AT' => ['flag' => '🇦🇹', 'name' => 'Avstriya'],
        'CH' => ['flag' => '🇨🇭', 'name' => 'Shveysariya'],
        'BE' => ['flag' => '🇧🇪', 'name' => 'Belgiya'],
        'PT' => ['flag' => '🇵🇹', 'name' => 'Portugaliya'],
        'GR' => ['flag' => '🇬🇷', 'name' => 'Gretsiya'],
        'HU' => ['flag' => '🇭🇺', 'name' => 'Vengriya'],
        'RO' => ['flag' => '🇷🇴', 'name' => 'Ruminiya'],
        'BG' => ['flag' => '🇧🇬', 'name' => 'Bolgariya'],
        'IL' => ['flag' => '🇮🇱', 'name' => 'Isroil'],
        'SA' => ['flag' => '🇸🇦', 'name' => 'Saudiya Arabistoni'],
        'AE' => ['flag' => '🇦🇪', 'name' => 'Birlashgan Arab Amirliklari'],
        'SG' => ['flag' => '🇸🇬', 'name' => 'Singapur'],
        'MY' => ['flag' => '🇲🇾', 'name' => 'Malayziya'],
        'ID' => ['flag' => '🇮🇩', 'name' => 'Indoneziya'],
        'PH' => ['flag' => '🇵🇭', 'name' => 'Filippin'],
        'TH' => ['flag' => '🇹🇭', 'name' => 'Tailand'],
        'VN' => ['flag' => '🇻🇳', 'name' => 'Vyetnam'],
        'MX' => ['flag' => '🇲🇽', 'name' => 'Meksika'],
        'AR' => ['flag' => '🇦🇷', 'name' => 'Argentina'],
        'CL' => ['flag' => '🇨🇱', 'name' => 'Chili'],
        'CO' => ['flag' => '🇨🇴', 'name' => 'Kolumbiya'],
        'PE' => ['flag' => '🇵🇪', 'name' => 'Peru'],
        'EG' => ['flag' => '🇪🇬', 'name' => 'Misr'],
        'NG' => ['flag' => '🇳🇬', 'name' => 'Nigeriya'],
        'ZA' => ['flag' => '🇿🇦', 'name' => 'Janubiy Afrika'],
        'KE' => ['flag' => '🇰🇪', 'name' => 'Keniya'],
        'MA' => ['flag' => '🇲🇦', 'name' => 'Marokash'],
        'DZ' => ['flag' => '🇩🇿', 'name' => 'Jazoir'],
        'TN' => ['flag' => '🇹🇳', 'name' => 'Tunis'],
        'PK' => ['flag' => '🇵🇰', 'name' => 'Pokiston'],
        'BD' => ['flag' => '🇧🇩', 'name' => 'Bangladesh'],
        'LK' => ['flag' => '🇱🇰', 'name' => 'Shri-Lanka'],
        'NP' => ['flag' => '🇳🇵', 'name' => 'Nepal'],
        'IR' => ['flag' => '🇮🇷', 'name' => 'Eron'],
        'IQ' => ['flag' => '🇮🇶', 'name' => 'Iroq'],
        'SY' => ['flag' => '🇸🇾', 'name' => 'Suriya'],
        'JO' => ['flag' => '🇯🇴', 'name' => 'Iordaniya'],
        'LB' => ['flag' => '🇱🇧', 'name' => 'Livan'],
        'KW' => ['flag' => '🇰🇼', 'name' => 'Quvayt'],
        'QA' => ['flag' => '🇶🇦', 'name' => 'Qatar'],
        'OM' => ['flag' => '🇴🇲', 'name' => 'Ummon'],
        'YE' => ['flag' => '🇾🇪', 'name' => 'Yaman'],
        'BH' => ['flag' => '🇧🇭', 'name' => 'Bahrayn'],
        'MV' => ['flag' => '🇲🇻', 'name' => 'Maldiv'],
        'BT' => ['flag' => '🇧🇹', 'name' => 'Butan'],
        'MN' => ['flag' => '🇲🇳', 'name' => 'Mongoliya'],
        'AZ' => ['flag' => '🇦🇿', 'name' => 'Ozarbayjon'],
        'AM' => ['flag' => '🇦🇲', 'name' => 'Armaniston'],
        'EC' => ['flag' => '🇪🇨', 'name' => 'Ekvador'],
        'CU' => ['flag' => '🇨🇺', 'name' => 'Kuba'],
    ];
    return $countries[$code] ?? ['flag' => '🏳️', 'name' => $code];
}
// ========== NOMER OLISH API FUNKSIYALARI TUGADI ==========

// ========== FUNKSIYALAR ==========
function sana($boshlangichSana, $oxirgiSana) {
    $boshlangichDateTime = new DateTime($boshlangichSana);
    $oxirgiDateTime = new DateTime($oxirgiSana);
    $farq = $boshlangichDateTime->diff($oxirgiDateTime);
    return $farq->days;
}

function determine($a,$b){
    $sanA = strtotime($a);
    $sanB = strtotime($b);
    if($sanA < $sanB){
        return "on";
    }elseif($sanB < $sanA){
        return "off";
    }else{
        return "on";
    }
}

function bot($method, $datas = []) {
    $url = "https://api.telegram.org/bot".Umidjon."/".$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($curlError) {
        bug_log('Telegram API CURL error', ['method' => $method, 'error' => $curlError]);
        return null;
    }
    $decoded = json_decode($res);
    if ($httpCode >= 400 || (isset($decoded->ok) && !$decoded->ok)) {
        bug_log('Telegram API response error', ['method' => $method, 'http' => $httpCode, 'response' => $res]);
    }
    return $decoded;
}

function send($text, $menu) {
    global $cid;
    bot('sendMessage', [
        'chat_id' => $cid,
        'text' => $text,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'reply_markup' => $menu
    ]);
}

function sendp($photo, $text, $menu) {
    global $cid;
    bot('sendPhoto', [
        'chat_id' => $cid,
        'photo' => $photo,
        'caption' => $text,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'reply_markup' => $menu
    ]);
}

function sendv($photo, $text, $menu) {
    global $cid;
    bot('sendVideo', [
        'chat_id' => $cid,
        'video' => $photo,
        'caption' => $text,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'reply_markup' => $menu
    ]);
}

function sendf($doc, $text, $menu) {
    global $cid;
    bot('SendDocument', [
        'chat_id' => $cid,
        'document' => $doc,
        'caption' => $text,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'reply_markup' => $menu
    ]);
}

function copyMessage($id, $from_chat_id, $message_id) {
    return bot('copyMessage', [
        'chat_id' => $id,
        'from_chat_id' => $from_chat_id,
        'message_id' => $message_id
    ]);
}

function forwardMessage($id, $cid, $mid) {
    return bot('forwardMessage', [
        'from_chat_id' => $id,
        'chat_id' => $cid,
        'message_id' => $mid
    ]);
}

function deldir($path) {
    if (is_dir($path)) {
        $files = array_diff(scandir($path), ['.', '..']);
        foreach ($files as $file) {
            $fullPath = $path . DIRECTORY_SEPARATOR . $file;
            deldir($fullPath);
        }
        return rmdir($path);
    } elseif (is_file($path)) {
        return unlink($path);
    }
    return false;
}

function edit($text, $key) {
    global $cid,$mid;
    return bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => $text,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'reply_markup' => $key
    ]);
}

function editm($text, $key) {
    global $cid, $mid;
    return bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => $text,
        'parse_mode' => 'markdown',
        'disable_web_page_preview' => true,
        'reply_markup' => $key
    ]);
}

function delete() {
    global $cid,$mid;
    return bot('deleteMessage', [
        'chat_id' => $cid,
        'message_id' => $mid,
    ]);
}

function put($addres, $value) {
    $a = file_put_contents($addres, $value);
    return $a;
}

function step($value) {
    global $connect,$cid;
    $a = mysqli_query($connect, "UPDATE users SET step = '$value' WHERE user_id = '$cid'");
    return $a;
}

function get($value) {
    $a = file_get_contents($value);
    return $a;
}

function ans($text) {
    global $qid;
    bot('answerCallbackQuery', [
        'callback_query_id' => $qid,
        'text' => $text,
        'show_alert' => true,
    ]);
}

function reaction($reaction) {
    global $cid, $mid;
    return bot('setmessagereaction', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'reaction' => json_encode(array([
            'type' => 'emoji',
            'emoji' => $reaction,
        ]))
    ]);
}

function is_admin($chat) {
    $url = "https://api.telegram.org/bot".Umidjon."/getChatAdministrators?chat_id=".$chat;
    $result = file_get_contents($url);
    $result = json_decode($result);
    return $result->ok;
}

function getName($id) {
    $getname = bot('getchat', ['chat_id' => $id])->result->first_name;
    if (!empty($getname)) {
        return $getname;
    } else {
        return bot('getchat', ['chat_id' => $id])->result->title;
    }
}

function hide($text) {
    $length = strlen($text);
    $sideLength = floor(($length - 5) / 2);
    $start = substr($text, 0, $sideLength);
    $end = substr($text, -$sideLength);
    return $start . '*****' . $end;
}

function mask($word) {
    $length = strlen($word);
    if ($length <= 4) {
        return str_repeat('*', $length);
    }
    $visiblePart = substr($word, 0, $length - 4);
    return $visiblePart . '****';
}

function referal($hi){
    $daten = [];
    $rev = [];
    $fayllar = glob("./ref/*.*");
    foreach($fayllar as $file){
        if(mb_stripos($file,".txt")!==false){
            $value = file_get_contents($file);
            $id = str_replace(["./ref/",".txt"],["",""],$file);
            $daten[$value] = $id;
            $rev[$id] = $value;
        }
        echo $file;
    }
    asort($rev);
    $reversed = array_reverse($rev);
    for($i=0;$i<$hi;$i+=1){
        $order = $i+1;
        $id = $daten["$reversed[$i]"];
        $ism=bot('getChat',[
            'chat_id'=>$id,
        ])->result->first_name;

        $text.= "<b>{$order}</b>. <a href='tg://user?id={$id}'>{$ism}</a> - "."<code>".floor($reversed[$i])."</code>"." <b> ta</b>"."\n";
    }
    return $text;
}

function referalid($hi){
    $daten = [];
    $rev = [];
    $fayllar = glob("./ref/*.*");
    foreach($fayllar as $file){
        if(mb_stripos($file,".txt")!==false){
            $value = file_get_contents($file);
            $id = str_replace(["./ref/",".txt"],["",""],$file);
            $daten[$value] = $id;
            $rev[$id] = $value;
        }
        echo $file;
    }
    asort($rev);
    $reversed = array_reverse($rev);
    for($i=0;$i<$hi;$i+=1){
        $order = $i+1;
        $id = $daten["$reversed[$i]"];
        $ism=bot('getChat',[
            'chat_id'=>$id,
        ])->result->first_name;

        $text.= "<b>{$order}</b>. <a href='tg://user?id={$id}'>{$ism}</a> - "."<code>".floor($reversed[$i])."</code>"." <b> ta</b>"."\n<b>ID raqami:</b> <code>{$id}</code>\n";
    }
    return $text;
}

function bormi($channelUsername, $userId) {
    $url = "https://api.telegram.org/bot" . Umidjon . "/getChatMember";
    $params = [
        'chat_id' => "@$channelUsername",
        'user_id' => $userId
    ];
    $response = file_get_contents($url . '?' . http_build_query($params));
    $data = json_decode($response, true);

    if (isset($data['ok']) && $data['ok'] === true) {
        $status = $data['result']['status'];
        if (in_array($status, ['member', 'administrator', 'creator'])) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function space($number) {
    return number_format($number, 0, '', ' ');
}

function joinchat($id) {
    global $mid, $kanalstatus;
    $array = array("inline_keyboard");
    $kanallar = file_get_contents("admin/kanal.txt");
    if ($kanallar == null or $kanalstatus == 'off') {
        return true;
    } else {
        $ex = explode("\n", $kanallar);
        for ($i = 0; $i <= count($ex) -1; $i++) {
            $first_line = $ex[$i];
            $first_ex = explode("@", $first_line);
            $url = $first_ex[1];
            $ism = bot('getChat', ['chat_id' => "@".$url,])->result->title;
            $ret = bot("getChatMember", [
                "chat_id" => "@$url",
                "user_id" => $id,
            ]);
            $stat = $ret->result->status;
            if ((($stat == "creator" or $stat == "administrator" or $stat == "member"))) {
                $array['inline_keyboard']["$i"][0]['text'] = $ism;
                $array['inline_keyboard']["$i"][0]['url'] = "https://t.me/$url";
            } else {
                $array['inline_keyboard']["$i"][0]['text'] = $ism;
                $array['inline_keyboard']["$i"][0]['url'] = "https://t.me/$url";
                $uns = true;
            }
        }
        $array['inline_keyboard']["$i"][0]['text'] = "✅ Davom etish ";
        $array['inline_keyboard']["$i"][0]['callback_data'] = "check";
        if ($uns == true) {
            bot('sendMessage', [
                'chat_id' => $id,
                'text' => "<b>🔒 Botdan foydalanish uchun kanallarga obuna bo‘ling:</b>",
                'parse_mode' => 'html',
                'disable_web_page_preview' => true,
                'reply_markup' => json_encode($array),
            ]);
            exit();
            return false;
        } else {
            return true;
        }
    }
}

function getCurrentUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $domain = $_SERVER['HTTP_HOST'];
    $uri = $_SERVER['REQUEST_URI'];
    return $protocol . $domain . $uri;
}

$update = json_decode(file_get_contents('php://input'));

if ($update->message) {
    $message = $update->message;
    $type = $message->chat->type;
    $text = $message->text;
    $cid = $message->chat->id;
    $uid = $message->from->id;
    $mid = $message->message_id;
    $username = $message->from->username;
    $firstname = $message->from->first_name;
    $name = str_replace(['<', '>'], [null, null], $firstname);
    $title = $message->chat->title;
    $repid = $message->reply_to_message->from->id;
    $repmid = $message->reply_to_message->message_id;
    $repuser = $message->reply_to_message->from->username;
    $repname = $message->reply_to_message->from->first_name;
    $replastname = $message->reply_to_message->from->last_name;
    $reply = $message->reply_to_message;
    $left = $message->left_chat_member;
    $new = $message->new_chat_member;
    $leftid = $message->left_chat_member->id;
    $newid = $message->new_chat_member->id;
    $newname = $message->new_chat_member->first_name;
    $photo = $message->photo;
    $pid = $photo[count($photo)-1]->file_id;
    $document = $message->document;
    $doc = $document->file_id;
    $successful_payment = $message->successful_payment;
    $contact = $message->contact;
    $contact_id = $contact->user_id;
    $contact_user = $contact->username;
    $contact_name = $contact->first_name;
    $phone = $contact->phone_number;
}

if ($update->callback_query) {
    $data = $update->callback_query->data;
    $mid = $update->callback_query->message->message_id;
    $username = $update->callback_query->message->chat->username;
    $cid = $update->callback_query->message->chat->id;
    $uid = $update->callback_query->from->id;
    $qid = $update->callback_query->id;
    $type = $update->callback_query->message->chat->type;
    $firstname = $update->callback_query->from->first_name;
    $name = str_replace(['<', '>'], [null, null], $firstname);
}

if ($update->pre_checkout_query) {
    $pre_checkout_query = $update->pre_checkout_query;
    $cid = $pre_checkout_query->from->id;
    $uid = $pre_checkout_query->from->id;
    $type = "private";
    $firstname = $pre_checkout_query->from->first_name;
    $name = str_replace(['<', '>'], [null, null], $firstname);
}

$del = $update->my_chat_member;
if ($del) {
    $botdel = $del->new_chat_member;
    $botdelid = $del->from->id;
    $userstatus = $botdel->status;
}

mysqli_query($connect, " CREATE TABLE IF NOT EXISTS `users`(
    `id` int(50) auto_increment primary key,
    `user_id` varchar(500),
    `username` varchar(255),
    `date` varchar(500),
    `step` varchar(500),
    `status` varchar(500),
    `ban` varchar(500),
    `money` varchar(500),
    `ref` varchar(500),
    `refid` varchar(500)
)");
db_add_column_if_missing($connect, 'users', 'username', 'varchar(255)');

mysqli_query($connect, " CREATE TABLE IF NOT EXISTS `admins`(
    `id` int(50) auto_increment primary key,
    `user_id` varchar(500)
)");

mysqli_query($connect, " CREATE TABLE IF NOT EXISTS `cheques`(
    `id` int(50) auto_increment primary key,
    `cheque` varchar(500),
    `money` varchar(500),
    `status` varchar(500),
    `user` varchar(500)
)");

mysqli_query($connect," CREATE TABLE IF NOT EXISTS send(
    id int(20) auto_increment primary key,
    time1 varchar(100),
    time2 varchar(100),
    time3 varchar(100),
    time4 varchar(100),
    time5 varchar(100),
    start_id varchar(100),
    stop_id varchar(100),
    admin_id varchar(100),
    message_id varchar(100),
    reply_markup varchar(100),
    step varchar(100)
)");

mysqli_query($connect," CREATE TABLE IF NOT EXISTS orders(
    `id` int(50) auto_increment primary key,
    `order_id` varchar(500),
    `user_id` varchar(500),
    `stars` varchar(1000),
    `status` varchar(1000),
    `price` varchar(1000),
    `priceton` varchar(1000),
    `username` varchar(1000),
    `time` varchar(1000)
)");

mysqli_query($connect," CREATE TABLE IF NOT EXISTS premium(
    `id` int(50) auto_increment primary key,
    `order_id` varchar(500),
    `user_id` varchar(500),
    `month` varchar(1000),
    `status` varchar(1000),
    `price` varchar(1000),
    `username` varchar(1000),
    `time` varchar(1000)
)");

mysqli_query($connect,"CREATE TABLE IF NOT EXISTS `auto_payments` (
    `id` int(20) auto_increment primary key,
    `user_id` varchar(256),
    `amount` varchar(256),
    `status` varchar(256),
    `time` varchar(256),
    `success_time` varchar(256)
)");

db_add_column_if_missing($connect, 'auto_payments', 'transaction_id', 'varchar(500)');
db_add_column_if_missing($connect, 'auto_payments', 'payment_url', 'text');

mysqli_query($connect,"CREATE TABLE IF NOT EXISTS `manual_payment_cards` (
    `id` int(20) auto_increment primary key,
    `card_number` varchar(64),
    `owner` varchar(255),
    `note` text,
    `status` varchar(32) default 'active',
    `created_at` varchar(64)
)");

mysqli_query($connect,"CREATE TABLE IF NOT EXISTS `manual_payments` (
    `id` int(20) auto_increment primary key,
    `user_id` varchar(256),
    `card_id` int(20),
    `amount` varchar(256),
    `status` varchar(32),
    `proof_chat_id` varchar(256),
    `proof_message_id` varchar(256),
    `admin_id` varchar(256),
    `admin_messages` text,
    `created_at` varchar(64),
    `checked_at` varchar(64)
)");

mysqli_query($connect,"CREATE TABLE IF NOT EXISTS `bot_star_topups` (
    `id` int(20) auto_increment primary key,
    `admin_id` varchar(256),
    `amount` varchar(256),
    `status` varchar(32),
    `payload` varchar(256),
    `created_at` varchar(64),
    `paid_at` varchar(64),
    `charge_id` varchar(500)
)");

$res = mysqli_query($connect, "SELECT*FROM `users` WHERE `user_id` = $cid");
while ($a = mysqli_fetch_assoc($res)) {
    $id = $a['id'];
    $user_id = $a['user_id'];
    $date = $a['date'];
    $step = $a['step'];
    $status = $a['status'];
    $ban = $a['ban'];
    $pul = $a['money'] ?? "0";
    $ref = $a['ref'] ?? "0";
    $refid = $a['refid'];
}

if(empty($pul)){
    $pul = "0";
}

if(empty($ref)){
    $ref = "0";
}

@mkdir("admin");
@mkdir("ref");
@mkdir("caches");
@mkdir("set");
@mkdir("konkurs");
@mkdir("bonus");
@mkdir("bots");
@mkdir("nomer_history");
@mkdir("tizim");
@mkdir("step");

// Fragment API kaliti fayli
if(!file_exists("set/fragment_api_key.txt")) {
    file_put_contents("set/fragment_api_key.txt", "");
}

// Nomerga olish API kaliti fayli
if(!file_exists("set/raqam_api_key.txt")) {
    file_put_contents("set/raqam_api_key.txt", "");
}

// Nomerga olish foiz fayli
if(!file_exists("set/raqam_foiz.txt")) {
    file_put_contents("set/raqam_foiz.txt", "20");
}

// Nomerga olish kanal fayli
if(!file_exists("nomer_ch.txt")) {
    file_put_contents("nomer_ch.txt", "");
}

// Jami sotilgan raqamlar fayli
if(!file_exists("tizim/jamiraqam.txt")) {
    file_put_contents("tizim/jamiraqam.txt", "0");
}

// Gift buyurtmalar papkasi
if(!is_dir("gift_orders")) {
    mkdir("gift_orders", 0777, true);
}

// Gift fayli
if(!file_exists("gifts.json")) {
    file_put_contents("gifts.json", "[]");
}

$orqa = "⏭️ Orqaga";
$kanal = @get("admin/kanal.txt");
$bonus = @get("bonus/$cid.txt");
$solved = @get("admin/solved.txt");
$won = @get("admin/won.txt");
$min = @get("admin/min.txt");
$startmsg = @get("admin/start.txt");
$refpay = @get("admin/refpay.txt");
$refpay2 = @get("admin/refpay2.txt");
$manual = @get("admin/manual.txt");
$payouts = @get("admin/payouts.txt");
$kanalstatus = @get("admin/kstatus.txt");
$seed = @file_get_contents("set/24.txt");
$star = @file_get_contents("set/50.txt");
if(empty($star)) {
    $star = 220;
    file_put_contents("set/50.txt", 220);
}

$oy1 = @file_get_contents("set/oy1.txt");
$oy3 = @file_get_contents("set/oy3.txt");
$oy6 = @file_get_contents("set/oy6.txt");
$oy12 = @file_get_contents("set/oy12.txt");

$foiz = @file_get_contents("set/foiz.txt");

$raqam_api = @file_get_contents("set/raqam_api_key.txt");
$raqam_foiz = @file_get_contents("set/raqam_foiz.txt");
$nomer_kanal = @file_get_contents("nomer_ch.txt");
$jamiraqam = @file_get_contents("tizim/jamiraqam.txt");

$apikay = @file_get_contents("set/apikay.txt");
$checkapi = @file_get_contents("set/checkapi.txt");

$konkurs = @get("set/konkurs.txt");
$konkursinfo = @get("set/konkurs.info");

$admin = @get("set/admin.txt");
$adminuser = @get("set/user.txt");
$admin_lk_url = "tg://user?id=" . trim((string)$admin);
$created = @get("set/created.txt");
$paytime = @get("set/paytime.txt");

if (empty($admin)) {
    $admin = $devid;
    put("set/admin.txt", $devid);
}
$admin_lk_url = "tg://user?id=" . trim((string)$admin);

if (empty($refpay)) {
    put("admin/refpay.txt", 0);
}

if (empty($oy3)) {
    put("set/oy3.txt", 170000);
}

if (empty($oy6)) {
    put("set/oy6.txt", 245000);
}

if (empty($oy12)) {
    put("set/oy12.txt", 410000);
}

if (empty($oy1)) {
    put("set/oy1.txt", 50000);
}

if(empty($adminuser)){
    $adminuser = 'null';
    put("set/user.txt",'admin_user');
}

if (empty($payouts)) {
    put("admin/payouts.txt", "@channel");
}

if(empty($konkurs)){
    put("set/konkurs.txt",'off');
}

if(empty($star)){
    put("set/50.txt",'220');
}

if (empty($kanalstatus)) {
    put("admin/kstatus.txt", 'on');
}

if(empty($paytime)){
    $day = date('d.m.Y', strtotime('+30 days')); 
    put("set/paytime.txt",$day);
}

$admins = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `admins` WHERE `user_id` = '$cid'"));

if (!$admins) {
    if ($ban == "1") {
        exit();
    }
}

if ($type == "private") {
    $safeUsername = sql_escape($username ?? '');
    $result = mysqli_query($connect, "SELECT * FROM `users` WHERE `user_id` = $cid");
    $rew = mysqli_fetch_assoc($result);
    if ($rew) {
        $status = $rew['status'];
        if ($status == "0") {
            mysqli_query($connect, "UPDATE `users` SET `status` = '1' WHERE `user_id` = '$cid'");
        }
        mysqli_query($connect, "UPDATE `users` SET `username` = '$safeUsername' WHERE `user_id` = '$cid'");
    } else {
        mysqli_query($connect, "INSERT INTO `users`(`user_id`,`username`,`date`, `step`, `status`, `ban`, `money`, `ref`) VALUES ('$cid','$safeUsername','$sana','0','1','0','0','0')");
    }
}

if (isset($message)) {
    $adm = mysqli_query($connect, "SELECT * FROM `admins` WHERE `user_id` = '$admin'");
    $adm = mysqli_fetch_assoc($adm);
    $fine = $adm['user_id'];
    if ($adm) {} else {
        mysqli_query($connect, "INSERT INTO `admins`(`user_id`) VALUES ($admin)");
    }
}

if ($botdel) {
    if ($userstatus == "kicked") {
        mysqli_query($connect, "UPDATE `users` SET `status` = '0' WHERE `user_id` = $botdelid");
    }
}

$orqa = "🔙Orqaga";

$menu = json_encode([
'inline_keyboard' => [

[
['icon_custom_emoji_id'=>"5942783678668085067",'text'=>" Stars olish",'callback_data'=>"stars"],
['icon_custom_emoji_id'=>"5935933437759198435",'text'=>"Premium olish",'callback_data'=>"premium"]
],

[
['icon_custom_emoji_id'=>"5938345530047337186",'text'=>"Gift Olish",'callback_data'=>"giftsho"]
],

[
['icon_custom_emoji_id'=>"5879770735999717115",'text'=>" Mening profilim",'callback_data'=>"cabinet"],
['icon_custom_emoji_id'=>"5927169041595634481",'text'=>" Pul kiritish",'callback_data'=>"topups"]
],

[
['icon_custom_emoji_id'=>"5472201536727686043",'text'=>"Qo'llab Quvvatlash",'callback_data'=>"support"]
]

]
]);

$can = json_encode(['inline_keyboard' => [
    [['text' => $orqa,'callback_data'=>"start"]],
]]);

$check = json_encode(['inline_keyboard' => [
    [['text' => "✅ Davom etish", 'callback_data' => "check"]]
]]);

if ($cid == $devid) {
    $panel = json_encode(['inline_keyboard' => [
        [['icon_custom_emoji_id' => "5190806721286657692",'text'=>" Statistikani ko‘rish",'callback_data'=>"stat"]],
        [['icon_custom_emoji_id' => "5460704794039566340",'text' => " Xabar yuborish", 'callback_data' => "sendusers"], ['icon_custom_emoji_id' => "5458380353444003279",'text' => " Bot sozlamalari", 'callback_data' => "settings"]],
        [['icon_custom_emoji_id' => "5440895910949181931",'text' => " Foydalanuvchini boshqarish ", 'callback_data' => "infouser"]],
        [['icon_custom_emoji_id' => "5458603970916270333",'text'=>" Referal konkurs",'callback_data'=>"setkonkurs"],['icon_custom_emoji_id' => "5458661257190063912",'text' => " Chek yaratish", 'callback_data' => "cheque"]],
        [['icon_custom_emoji_id' => "5460729979727788149",'text' => " Majburiy obuna", 'callback_data' => "channels"],['icon_custom_emoji_id' => "6039402906476613311",'text' => " Premiumlar", 'callback_data' => "payouts"]],
        [['icon_custom_emoji_id' => "5438553238217450600",'text'=>" Stars API",'callback_data'=>"starapi"],['icon_custom_emoji_id' => "5440725903258704836",'text'=>" Nomer API",'callback_data'=>"raqamapi"]],
        [['icon_custom_emoji_id' => "5927169041595634481",'text' => " To‘lov tizimi", 'callback_data'=>"manualpay_admin"],['icon_custom_emoji_id' => "5935933437759198435",'text' => " Stars to‘ldirish", 'callback_data'=>"admin_stars_topup"]],
        [['icon_custom_emoji_id' => "5463289629912348180",'text' => " Admin sozlash", 'callback_data' => "adminid"]],
    ]]);
} else {
    $panel = json_encode(['inline_keyboard' => [
        [['icon_custom_emoji_id' => "5190806721286657692",'text'=>" Statistikani ko‘rish",'callback_data'=>"stat"]],
        [['icon_custom_emoji_id' => "5460704794039566340",'text' => " Xabar yuborish", 'callback_data' => "sendusers"], ['icon_custom_emoji_id' => "5458380353444003279",'text' => " Bot sozlamalari", 'callback_data' => "settings"]],
        [['icon_custom_emoji_id' => "5440895910949181931",'text' => " Foydalanuvchini boshqarish ", 'callback_data' => "infouser"]],
        [['icon_custom_emoji_id' => "5458603970916270333",'text'=>" Referal konkurs",'callback_data'=>"setkonkurs"],['icon_custom_emoji_id' => "5458661257190063912",'text' => " Chek yaratish", 'callback_data' => "cheque"]],
        [['icon_custom_emoji_id' => "5460729979727788149",'text' => " Majburiy obuna", 'callback_data' => "channels"],['icon_custom_emoji_id' => "6039402906476613311",'text' => " Premiumlar", 'callback_data' => "payouts"]],
        [['icon_custom_emoji_id' => "5438553238217450600",'text'=>" Stars API",'callback_data'=>"starapi"],['icon_custom_emoji_id' => "5440725903258704836",'text'=>" Nomer API",'callback_data'=>"raqamapi"]],
        [['icon_custom_emoji_id' => "5927169041595634481",'text' => " To‘lov tizimi", 'callback_data'=>"manualpay_admin"],['icon_custom_emoji_id' => "5935933437759198435",'text' => " Stars to‘ldirish", 'callback_data'=>"admin_stars_topup"]],
    ]]);
}

$backpanel = json_encode(['inline_keyboard' => [
    [['text' => $orqa, 'callback_data' => "panel"]],
]]);

$start = "<tg-emoji emoji-id='5422823770899375641'>🌟</tg-emoji>  <b>Assalom alaykum, <a href='tg://user?id=$cid'>{$name}</a> botga xush kelibsiz!</b>

<tg-emoji emoji-id='5420644242500381481'>🌟</tg-emoji> Bot orqali «<tg-emoji emoji-id='5942783678668085067'>🌟</tg-emoji> Telegram Stars» va «<tg-emoji emoji-id='5935933437759198435'>💠</tg-emoji> Telegram Premium» larni xarid qilishingiz mumkin

<b>Quyidagi menyudan keraklisini tanlang <tg-emoji emoji-id='5231102735817918643'>👇</tg-emoji></b>";

// ========== NOMER OLISH HANDLER ==========
if ($text == "📞 Nomer olish" or $data == "raqam_olish") {
    if (empty($raqam_api) or $raqam_api == "") {
        if ($data == "raqam_olish") {
            delete();
        }
        send("<b>⚠️ Nomera olish API kaliti kiritilmagan! Admin panel orqali sozlang.</b>", $menu);
        exit();
    }

    $send = bot('sendMessage', ['chat_id' => $cid, 'text' => "<b>♻️ Davlatlar qidirilmoqda...</b>", 'parse_mode' => 'html']);
    $edmi = $send->result->message_id;

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=getCountries"), true);

    if (!$api_response['ok']) {
        bot('editMessageText', ['chat_id' => $cid, 'message_id' => $edmi, 'text' => "<b>❌ Xatolik yuz berdi! API kalitni tekshiring.</b>", 'parse_mode' => 'html']);
        exit();
    }

    $countries = formatCountries($api_response['result']['countries']);
    $page = 0;
    $perPage = 10;
    $total = count($countries);
    $list = array_slice($countries, $page * $perPage, $perPage);

    $keyboard = buildCountriesKeyboard($list, $page, $total, $perPage);
    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $edmi,
        'text' => "<tg-emoji emoji-id=\"5461054558996282111\">👋</tg-emoji> Topilgan davlatlar ro'yxati:",
        'reply_markup' => $keyboard,
        'parse_mode' => 'html'
    ]);
    order_unlock('gift', $cid . '_' . $gift['id']);
    exit();
}

// Davlatlar sahifalari
if (mb_stripos($data, "allcountries22=") !== false) {
    if (empty($raqam_api)) {
        ans("⚠️ API kalit sozlanmagan!");
        exit();
    }

    $ex = explode("=", $data);
    $currentPage = (int) $ex[1];
    $direction = $ex[2];
    $page = $direction == "next" ? $currentPage + 1 : max(0, $currentPage - 1);

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=getCountries"), true);
    $countries = formatCountries($api_response['result']['countries']);

    $perPage = 10;
    $total = count($countries);
    $list = array_slice($countries, $page * $perPage, $perPage);

    $keyboard = buildCountriesKeyboard($list, $page, $total, $perPage);
    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => "<tg-emoji emoji-id=\"5461054558996282111\">👋</tg-emoji> Topilgan davlatlar ro'yxati:",
        'reply_markup' => $keyboard,
        'parse_mode' => 'html'
    ]);
    exit();
}

// TOP 10 davlatlar
if ($data == "top10") {
    if (empty($raqam_api)) {
        ans("⚠️ API kalit sozlanmagan!");
        exit();
    }

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=getCountries"), true);
    $countries = formatCountries($api_response['result']['countries']);

    shuffle($countries);
    $list = array_slice($countries, 0, 10);

    $keyboard = buildTopCheapKeyboard($list, "top10");
    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => "<b>🏆 TOP 10 davlatlar:</b>",
        'reply_markup' => $keyboard,
        'parse_mode' => 'html'
    ]);
    exit();
}

// Eng arzon davlatlar
if ($data == "cheap") {
    if (empty($raqam_api)) {
        ans("⚠️ API kalit sozlanmagan!");
        exit();
    }

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=getCountries"), true);
    $countries = formatCountries($api_response['result']['countries']);

    usort($countries, function ($a, $b) {
        return $a['price_uzs'] <=> $b['price_uzs'];
    });

    $list = array_slice($countries, 0, 10);
    $keyboard = buildTopCheapKeyboard($list, "cheap");
    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => "<b>📉 Eng arzon raqamlar:</b>",
        'reply_markup' => $keyboard,
        'parse_mode' => 'html'
    ]);
    exit();
}

// Bekor qilish
if ($data == "bekorqil") {
    bot('deleteMessage', ['chat_id' => $cid, 'message_id' => $mid]);
    bot('sendMessage', ['chat_id' => $cid, 'text' => "<b>⛔️ Bekor qilindi.</b>", 'parse_mode' => 'html']);
    exit();
}

// Raqam tanlash
if (mb_stripos($data, "get_number=") !== false) {
    $ex = explode("=", $data);
    $price = $ex[1];
    $code = $ex[2];
    $country = $ex[3];

    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => "<b>🛍️ Siz sotib olmoqchi bo'layotgan raqam haqida ma'lumot:

🌍 Mamlakat: $country
💰 Narxi: $price so'm

⚠️ Bizda faqat tayyor akkauntlar bo'lgani uchun faqat telegram uchun nomerlar olishingiz mumkin.
✅ Raqamlar haqiqiy hisob bo'lgani uchun 2 bosqichli paroli bo'lishi mumkin bunga e'tibor bermaysiz. Sinovdan o'tgan o'chmaydigan raqam beriladi sizga.

<blockquote>‼️Raqamni Telegramning rasmiy ilovasidan olmang! Norasmiy telegramdan olish tavsiya beriladi!</blockquote></b>",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "✅ Tasdiqlash", 'callback_data' => "get_true=$price=$code=$country"]],
                [['text' => "🚫 Bekor qilish", 'callback_data' => "bekorqil"]],
            ]
        ]),
        'parse_mode' => 'html'
    ]);
    exit();
}

// Raqam sotib olish
if (mb_stripos($data, "get_true=") !== false) {
    $ex = explode("=", $data);
    $price = $ex[1];
    $code = $ex[2];
    $country = $ex[3];

    if ($pul < $price) {
        ans("⛔️ Yetarli mablag' mavjud emas!", true);
        exit();
    }

    bot('deleteMessage', ['chat_id' => $cid, 'message_id' => $mid]);

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=buyNumber&country_code=$code"), true);

    if ($api_response['ok']) {
        $order_id = $api_response['result']['order_id'];
        $phone = $api_response['result']['phone'];

        // Balansni yangilash
        $new_balans = $pul - $price;
        mysqli_query($connect, "UPDATE users SET money = '$new_balans' WHERE user_id = '$cid'");

        // Tarixga qo'shish
        $history_file = "nomer_history/$cid.json";
        if (file_exists($history_file)) {
            $history = json_decode(file_get_contents($history_file), true);
        } else {
            $history = [];
        }
        $history[] = [
            'phone' => $phone,
            'country' => $country,
            'price' => $price,
            'date' => date('d.m.Y H:i'),
            'order_id' => $order_id
        ];
        file_put_contents($history_file, json_encode($history));

        // Jami raqamlar sonini oshirish
        $jamiraqam++;
        file_put_contents("tizim/jamiraqam.txt", $jamiraqam);

        // Kanalga yuborish
        if (!empty($nomer_kanal)) {
            $log_image = "https://t.me/qora_tanli/19";
            $text = "<b>✅ Yangi raqam olindi! #$order_id</b>\n\n"
                . "<b>📱 Olingan raqam:</b> <code>$phone</code>\n"
                . "<b>💰 Narxi:</b> $price so'm\n"
                . "<b>🌍 Mamlakat:</b> $country\n"
                . "<b>👤 Foydalanuvchi:</b> <a href='tg://user?id=$cid'>$name</a>\n\n"
                . "<b>@$bot - biznesingiz hamkori</b>";

            bot('sendPhoto', [
                'chat_id' => $nomer_kanal,
                'photo' => $log_image,
                'caption' => $text,
                'parse_mode' => 'html',
                'reply_markup' => json_encode([
                    'inline_keyboard' => [[['text' => "🤖 Botga o'tish", 'url' => "https://t.me/$bot"]]]
                ])
            ]);
        }

        bot('sendMessage', [
            'chat_id' => $cid,
            'text' => "<b>✅ Muvaffaqiyatli! Raqam olindi.\n\n📞 Raqamni hohlagan Telegram ilovasiga kiriting va <b>SMS kodni olish</b> tugmasini bosing.\n\n⚠️ Raqam spam bo'lishi mumkin. 2 bosqichli parolni 1.5 kundan keyin qo'ying, aks holda raqam bloklanadi.\n\n📞 <b>Sizning raqamingiz:</b> <code>$phone</code>\n🆔 <b>Buyurtma ID:</b> <code>$order_id</code></b>",
            'parse_mode' => 'html',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [['text' => "🔢 KODni olish", 'callback_data' => "getsms2=$order_id"]],
                ]
            ])
        ]);
    } else {
        bot('sendMessage', ['chat_id' => $cid, 'text' => "<b>❌ Xatolik: " . ($api_response['msg'] ?? 'Nomalum') . "</b>", 'parse_mode' => 'html']);
    }
    exit();
}

// SMS kod olish
if (mb_stripos($data, "getsms2=") !== false) {
    $order_id = explode("=", $data)[1];

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=getCode&order_id=$order_id"), true);

    if ($api_response['ok']) {
        if ($api_response['status'] == 'waiting') {
            ans("⏳ SMS kutilmoqda...", true);
        } elseif ($api_response['status'] == 'finished') {
            $code = $api_response['result']['code'];
            $password = $api_response['result']['password'] ?? '';
            $phone = $api_response['result']['phone'];

            $msg = "<b>✅ SMS qabul qilindi!\n\n📞 Raqam: <code>$phone</code>\n🔢 SMS Kodi: <code>$code</code>";
            if (!empty($password)) {
                $msg .= "\n🔐 Parol: <code>$password</code>";
            }
            $msg .= "</b>";

            bot('sendMessage', ['chat_id' => $cid, 'text' => $msg, 'parse_mode' => 'html']);
        }
    } else {
        ans("🚫 SMS kod olishda xatolik!", true);
    }
    exit();
}

// Foydalanuvchi raqamlari (user uchun)
if ($data == "raqamlarim_user" and joinchat($cid) == true) {
    $history_file = "nomer_history/$cid.json";

    if (file_exists($history_file)) {
        $history = json_decode(file_get_contents($history_file), true);
        $message = "<b>📜 Sotib olgan raqamlar:</b>\n\n";

        foreach (array_slice($history, 0, 10) as $item) {
            $message .= "📱 Raqam: <code>{$item['phone']}</code>\n🌍 Davlat: {$item['country']}\n💰 Narxi: {$item['price']} so'm\n⏰ {$item['date']}\n━━━━━━━━━━━━\n";
        }

        if (count($history) > 10) {
            $message .= "\n📊 Jami: " . count($history) . " ta raqam";
        }
    } else {
        $message = "<b>📭 Siz hali raqam sotib olmagansiz</b>";
    }
    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => $message,
        'parse_mode' => 'html',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['icon_custom_emoji_id' => "5332724926216428039",'text' => " Kodni Tekshirish", 'callback_data' => "tekshiraqam"]],
                [['icon_custom_emoji_id' => "5278702045883292456",'text' => " Orqaga", 'callback_data' => "start"]]
            ]
        ])
    ]);
    exit();
}

// Raqam tekshirish (callback)
if ($data == "tekshiraqam") {
    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => "<b>🔢 Buyurtma ID raqamini kiriting:</b>",
        'parse_mode' => 'html',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['icon_custom_emoji_id' => "5278702045883292456",'text' => " Orqaga", 'callback_data' => "raqamlarim_user"]]
            ]
        ])
    ]);
    step("tekshiraqam");
    exit();
}

// Buyurtma ID tekshirish
if ($step == "tekshiraqam" and isset($text)) {
    $order_id = trim($text);

    $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$raqam_api&action=getCode&order_id=$order_id"), true);

    if ($api_response['ok']) {
        if ($api_response['status'] == 'waiting') {
            send("<b>⏳ SMS kutilmoqda... Iltimos, kuting.</b>", $can);
        } elseif ($api_response['status'] == 'finished') {
            $code = $api_response['result']['code'];
            $password = $api_response['result']['password'] ?? '';
            $phone = $api_response['result']['phone'];

            $msg = "<b>✅ SMS qabul qilindi!\n\n📞 Raqam: <code>$phone</code>\n🔢 SMS Kodi: <code>$code</code>";
            if (!empty($password)) {
                $msg .= "\n🔐 Parol: <code>$password</code>";
            }
            $msg .= "</b>";

            send($msg, $can);
        }
    } else {
        send("<b>❌ Buyurtma topilmadi yoki xatolik yuz berdi.</b>", $can);
    }
    step("0");
    exit();
}
// ========== NOMER OLISH HANDLER TUGADI ==========



if ($text == "/start") {
    if (joinchat($cid) == true) {
        reaction("🏆");
        send($start, $menu);
        step('0');
        exit();
    }
}

if ($data == "start") {
    delete();
    if (joinchat($cid) == true) {
        send($start, $menu);
        step('0');
        exit();
    }
}

if(mb_stripos($data,"cancel=")!==false){
    $id = explode("=",$data)[1];
    delete();
    mysqli_query($connect,"DELETE FROM orders WHERE id = '$id'");
    send($start, $menu);
    step('0');
    exit();
}

if(mb_stripos($data,"cancelprem=")!==false){
    $id = explode("=",$data)[1];
    delete();
    mysqli_query($connect,"DELETE FROM premium WHERE id = '$id'");
    send($start, $menu);
    step('0');
    exit();
}

if ($text == $orqa and joinchat($cid) == true) {
    send($start, $menu);
    step('0');
    exit();
}

if($data == "cabinet" and joinchat($cid) == true){
    $key = json_encode(['inline_keyboard' => [
        [
            ['icon_custom_emoji_id' => "5846008814129649022", 'text' => "Referal", 'callback_data' => "referal"],
            ['icon_custom_emoji_id' => "5927169041595634481", 'text' => " Pul kiritish", 'callback_data' => "topups"]
        ],
        [
            ['text' => $orqa, 'callback_data' => "start"]
        ]
    ]]);
    
    // Foydalanuvchi ma'lumotlarini olish
    $user_query = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$cid'");
    $user_data = mysqli_fetch_assoc($user_query);
    $user_name = $name; // $name globalda mavjud
    $user_id = $cid;
    
    // Buyurtmalar statistikasi
    $sqx = mysqli_query($connect, "SELECT SUM(stars) AS total_stars FROM orders WHERE status = 'paid' AND user_id = '$cid'");
    $rowx = mysqli_fetch_assoc($sqx);
    $totalStars = $rowx['total_stars'] ?? 0;
    
    // Jami sarf (buyurtmalar summasini pulda hisoblash)
    $sq_cost = mysqli_query($connect, "SELECT SUM(price) AS total_cost FROM orders WHERE status = 'paid' AND user_id = '$cid'");
    $row_cost = mysqli_fetch_assoc($sq_cost);
    $totalCost = $row_cost['total_cost'] ?? 0;
    
    // Kiritilgan pul (avtomatik to'lovlar)
    $sqo = mysqli_query($connect, "SELECT SUM(amount) AS total_amount FROM auto_payments WHERE status = 'success' AND user_id = '$cid'");
    $rowo = mysqli_fetch_assoc($sqo);
    $totalAmount = $rowo['total_amount'] ?? 0;
    
    // Qo'lda to'lovlar (tasdiqlangan)
    $sq_manual = mysqli_query($connect, "SELECT SUM(amount) AS total_manual FROM manual_payments WHERE user_id = '$cid' AND status = 'approved'");
    $row_manual = mysqli_fetch_assoc($sq_manual);
    $totalManual = $row_manual['total_manual'] ?? 0;
    
    // Jami kiritilgan pul (avtomatik + qo'lda)
    $totalDeposit = $totalAmount + $totalManual;
    
    // Asosiy balans (foydalanuvchining joriy balansi)
    $balance = $pul; // $pul globalda mavjud
    
    // Referallar soni
    $ref_count = $ref; // $ref globalda mavjud
    
    // Referal daromad (agar mavjud bo'lsa)
    $ref_income = 0;
    $ref_income_query = mysqli_query($connect, "SELECT SUM(refpay) AS ref_income FROM referal_earnings WHERE user_id = '$cid'");
    if($ref_income_query){
        $ref_income_data = mysqli_fetch_assoc($ref_income_query);
        $ref_income = $ref_income_data['ref_income'] ?? 0;
    }
    
    // Yangilangan vaqt
    $update_time = date("H:i");
    
    $cabinet_text = "<tg-emoji emoji-id=\"5350404270032166927\">👤</tg-emoji>  <b>Shaxsiy kabinet</b>\n\n";
    $cabinet_text .= "┌ Ism: <b>{$user_name}</b>\n";
    $cabinet_text .= "└ ID: <code>{$user_id}</code>\n\n";
    $cabinet_text .= "<tg-emoji emoji-id=\"5409048419211682843\">🔄</tg-emoji>  <b>Moliya:</b>\n";
    $cabinet_text .= "┌ Asosiy balans: <b>" . number_format($balance, 0, '.', ' ') . " so'm</b>\n";
    $cabinet_text .= "├ Jami sarf: <b>" . number_format($totalCost, 0, '.', ' ') . " so'm</b>\n";
    $cabinet_text .= "└ Kiritilgan: <b>" . number_format($totalDeposit, 0, '.', ' ') . " so'm</b>\n\n";
    $cabinet_text .= "<tg-emoji emoji-id=\"5231200819986047254\">🔄</tg-emoji>  <b>Statistika:</b>\n";
    $cabinet_text .= "┌ Takliflar: <b>{$ref_count} kishi</b>\n";
    $cabinet_text .= "└ Telegram Stars: <b>{$totalStars} ⭐️</b>\n\n";
    $cabinet_text .= "<tg-emoji emoji-id=\"5985570164345671799\">🔄</tg-emoji>  Yangilangan vaqt: <b>{$update_time}</b>";
    
    edit($cabinet_text, $key);
    exit();
}
// STARS NARXLARI (DINAMIK)
$star_price = intval($star);
$price_list = [
    50   => 50 * $star_price,
    75   => 75 * $star_price,
    100  => 100 * $star_price,
    150  => 150 * $star_price,
    250  => 250 * $star_price,
    350  => 350 * $star_price,
    500  => 500 * $star_price,
    750  => 750 * $star_price,
    1000 => 1000 * $star_price,
    1500 => 1500 * $star_price,
    2500 => 2500 * $star_price,
    2750=> 2750 * $star_price,
    3000 => 3000 * $star_price,
    5000 => 5000 * $star_price,
    7500 => 7500 * $star_price,
    10000 => 10000 * $star_price


];

if($data == "stars" and joinchat($cid) == true){
    $jx = bot('editMessageText',[
        'message_id'=>$mid,
        'chat_id'=>$cid,
        'parse_mode'=>'html',
        'text'=>"<tg-emoji emoji-id=\"5334804600920747400\">🔄</tg-emoji> <b>Yuklanmoqda...</b>"
    ])->result->message_id;
    
    $buttons = [];
    $star_icons = ["5920281855378068765", "5920281855378068765", "5920281855378068765", "5920281855378068765"];
    $i = 0;
    foreach ($price_list as $starx => $price) {
        $narx = number_format($price, 0, '.', ' ');
        $buttons[] = [
            'icon_custom_emoji_id' => $star_icons[$i++ % count($star_icons)],'text' => " $starx  - $narx so'm",
            'callback_data' => "star=$starx=$price"
        ];
    }
    $inline_keyboard = array_chunk($buttons, 2);
    $inline_keyboard[] = [
        ['text' => $orqa, 'callback_data' => "start"]
    ];
    $key = json_encode(['inline_keyboard' => $inline_keyboard]);
    sleep(1);
    
    $text = "<tg-emoji emoji-id='5942783678668085067'>⭐</tg-emoji> <b>Telegram Stars xarid qilish</b>\n\n"
        . "<b><tg-emoji emoji-id='5386313185923978569'>⭐</tg-emoji>Cheklovlar</b>\n"
        . "<blockquote><tg-emoji emoji-id='5334863583706622360'>⭐</tg-emoji>Minimal: 50 ta\n<tg-emoji emoji-id='5334863583706622360'>⭐</tg-emoji>Maksimal: 7860 ta</blockquote>\n\n"
        . "<tg-emoji emoji-id='5226513232549664618'>⭐</tg-emoji> Kerakli miqdorni tanlang\n";
    
    bot('editMessageText',[
        'chat_id'=>$cid,
        'message_id'=>$jx,
        'parse_mode'=>'html',
        'text'=>$text,
        'reply_markup'=>$key
    ]);
    exit();
}
if(mb_stripos($data,"star=")!==false){
    $jx = bot('editMessageText',[
        'message_id'=>$mid,
        'chat_id'=>$cid,
        'parse_mode'=>'html',
        'text'=>"<tg-emoji emoji-id=\"5334804600920747400\">🔄</tg-emoji> <b>Yuklanmoqda...</b>"
    ])->result->message_id;
    $starx = explode("=",$data)[1];
    $narxi = explode("=",$data)[2];
    $key = json_encode(['inline_keyboard' =>[
        [['icon_custom_emoji_id' => "6032608126480421344",'text'=>" O‘zimga",'callback_data'=>"myself"]],
        [['text'=>$orqa,'callback_data'=> "stars"]]
    ]]);
    sleep(1);
    bot('editMessageText',[
        'chat_id'=>$cid,
        'message_id'=>$jx,
        'parse_mode'=>'html',
        'text'=>"<tg-emoji emoji-id='5771887475421090729'>👤</tg-emoji> Foydalanuvchi nomi

<blockquote><tg-emoji emoji-id='5954175920506933873'>🌀</tg-emoji>Biz Telegram Stars'larni qaysi profilga yuborishimizni aniqlashtirib olishimiz kerak. Aniqlashtirib olishimiz uchun foydalanuvching usernameni yuboring

<tg-emoji emoji-id='5879770735999717115'>🌀</tg-emoji>Masalan: @StazGoHelp</blockquote>

<tg-emoji emoji-id='5879841310902324730'>✏️</tg-emoji>  Kerakli usernameni yuboring",
        'reply_markup'=>$key
    ]);
    step($data);
    exit();
}

if(mb_stripos($step,"star=")!==false){
    $starx = explode("=",$step)[1];
    $narxi = explode("=",$step)[2];
    if($data == "myself"){
        $use = $username;
    }elseif(isset($text)){
        $use = $text;
    }
    $user = clean_username($use ?? '');
    if($user != null){
        step("0");
        mysqli_query($connect,"INSERT INTO orders(`user_id`,`stars`,`status`,`price`,`username`,`time`) VALUES ('$cid','$starx','pending','$narxi','$user','$sana')");
        $last_id = mysqli_insert_id($connect);
        $price = space($narxi);
        
        $key = json_encode(['inline_keyboard' =>[
            [['icon_custom_emoji_id' => "5143290574673019778", 'text'=>"Tasdiqlash", 'callback_data'=>"refdan=$last_id"]],
            [['text'=>$orqa, 'callback_data'=> "cancel=$last_id"]]
        ]]);
        
        $texit = "<b><tg-emoji emoji-id='5983399041197675256'>📋</tg-emoji> Buyurtma yaratildi</b>\n\n"
            . "<blockquote>◾️ <b>Turi:</b> <tg-emoji emoji-id='5897658922600240288'>⭐</tg-emoji> Telegram Stars\n"
            . "◾️ <b>Username:</b> @$user\n"
            . "◾️ <b>Soni:</b> $starx ta\n"
            . "◾️ <b>Summa:</b> $price so'm</blockquote>\n"
            . "<tg-emoji emoji-id='5927169041595634481'>⏰</tg-emoji> To'lov amalga oshirilgach, buyurtma avtomatik yuboriladi\n";
        
        if(isset($text)){
            send($texit,$key);
            step("0");
            exit();
        }elseif($data == "myself"){
            edit($texit,$key);
            step("0");
            exit();
        }
    }else{
        ans("Sizda username mavjud emas!");
        exit();
    }
}

// ========== STARS API ORQALI SOTIB OLISH (AVTOMATIK) ==========
if(mb_stripos($data, "refdan=") !== false){
    $id = explode("=", $data)[1];
    $id = (int)$id;
    if (!order_lock('stars', $id)) { ans("⏳ Buyurtma qayta ishlanmoqda, qayta bosmang.", true); exit(); }
    $ox = mysqli_query($connect, "SELECT * FROM orders WHERE id = $id AND status = 'pending'");
    $xx = mysqli_fetch_assoc($ox);
    if (!$xx) { order_unlock('stars', $id); ans("❌ Buyurtma topilmadi yoki allaqachon bajarilgan.", true); exit(); }
    $stars = $xx['stars'];
    $price = $xx['price'];
    $user = $xx['username'];

    if($pul >= $price){
        delete();
        
        // API kalitini o'qish
        $apiKey = trim(file_get_contents("set/fragment_api_key.txt"));
        
        if(empty($apiKey)){
            send("<b>❌ Fragment API sozlanmagan! Admin panelga kirib API kalitni kiriting.</b>", null);
            mysqli_query($connect, "DELETE FROM orders WHERE id = '$id'");
            order_unlock('stars', $id);
            exit();
        }
        
        // FragmentUzAPI class orqali stars sotib olish (AVTOMATIK)
        $fragment = new FragmentUzAPI($apiKey);
        $recipientInfo = $fragment->getInfo($user);
        if(!$recipientInfo){
            $error = $fragment->getLastError() ?? "Username Fragment orqali topilmadi";
            bug_log('Stars recipient check failed', ['order_id' => $id, 'user' => $user, 'error' => $error]);
            send("<b>❌ Username tekshiruvdan o‘tmadi:</b> " . h($error) . "\n\nUsername to‘g‘riligini tekshiring.", $menu);
            mysqli_query($connect, "DELETE FROM orders WHERE id = '$id'");
            order_unlock('stars', $id);
            step("0");
            exit();
        }
        $result = $fragment->buyStars($user, (int)$stars);
        
        if($result){
            $new = $pul - $price;
            $orid = mysqli_query($connect, "SELECT * FROM orders WHERE status = 'paid'");
            $orderid = mysqli_num_rows($orid);
            $orif = $orderid + 1;

            mysqli_query($connect, "UPDATE users SET money = '$new' WHERE user_id = '$cid'");
            mysqli_query($connect, "UPDATE orders SET order_id = '$orif', status = 'paid' WHERE id = '$id'");

            send("🎉 <b>Buyurtma muvaffaqiyatli bajarildi!</b>\n\n🆔 Buyurtma ID: #$orif\n⭐️ $stars Stars @$user ga yuborildi\n💰 Pul yechildi: $price so'm\n Foydalanganingiz uchun rahmat! 🪐", null);

            bot('sendMessage', [
                'chat_id' => $payouts,
                'parse_mode' => 'HTML',
                'text' => "🌟 <b>Stars buyurtma bajarildi:</b>\n🆔 Buyurtma ID: #$orif\n🔎 Nikneym: <a href='tg://user?id=$cid'>$name</a>\n🧮 Stars: $stars stars 💸\n💵 Narxi: $price so'm 🏷️\n✅ Status: confirmed"
            ]);

            order_unlock('stars', $id);
            step("0");
            exit();
        } else {
            $error = $fragment->getLastError() ?? "Noma'lum xatolik";
            bug_log('Stars auto buy failed', ['order_id' => $id, 'user' => $user, 'stars' => $stars, 'error' => $error]);
            send("<b>❌ Xatolik: $error</b>\n\nAPI kalitni tekshiring yoki balans yetarli ekanligiga ishonch hosil qiling.", null);
            send($start, $menu);
            mysqli_query($connect, "DELETE FROM orders WHERE id = '$id'");
            order_unlock('stars', $id);
            step("0");
            exit();
        }
    } else {
        $key = json_encode(['inline_keyboard' => [
            [['text' => "💶 Hisobni to‘ldirish", 'callback_data'=>"topups"]],
            [['text' => $orqa, 'callback_data'=>"start"]]
        ]]);
        edit("❌ <b>Hisobingizda mablag‘ yetarli emas</b>", $key);
        mysqli_query($connect, "DELETE FROM orders WHERE id = '$id'");
        order_unlock('stars', $id);
        exit();
    }
}

if($data == "premium" and joinchat($cid)==true){
    $oy_1 = space($oy1);
    $oy_3 = space($oy3);
    $oy_6 = space($oy6);
    $oy_12 = space($oy12);
    
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>" 3 oy - {$oy_3} so'm",'callback_data'=>"premium_oy3"]],
        [['text'=>" 6 oy - {$oy_6} so'm",'callback_data'=>"premium_oy6"]],
        [['text'=>" 12 oy - {$oy_12} so'm",'callback_data'=>"premium_oy12"]],
        [['text'=>$orqa,'callback_data'=>"start"]],
    ]]);
    
    $text = "<tg-emoji emoji-id='5935933437759198435'>💎</tg-emoji> <b>Telegram Premium</b>\n\n"
        . "<tg-emoji emoji-id='5879785854284599288'>💎</tg-emoji><b>IMKONIYATLAR</b>\n"
        . "<blockquote><tg-emoji emoji-id='5877613700344450910'>💎</tg-emoji> Tezroq yuklab olish tezligi\n"
        . "<tg-emoji emoji-id='5877316724830768997'>💎</tg-emoji> Kengaytirilgan xotira limiti\n"
        . "<tg-emoji emoji-id='5771511103141975115'>💎</tg-emoji> Reklamalarsiz foydalanish\n"
        . "<tg-emoji emoji-id='5897554554894946515'>💎</tg-emoji>Ovozni matnga aylantirish imkoniyati\n"
        . "<tg-emoji emoji-id='5942640218170461901'>💎</tg-emoji> Animatsiyali emoji va eksklyuziv stikerlar\n"
        . "<tg-emoji emoji-id='5994297722574737553'>💎</tg-emoji> Kengaytirilgan limitlar va chat boshqaruvi</blockquote>\n\n"
        . "<tg-emoji emoji-id='5226513232549664618'>💎</tg-emoji> <b>Telegram Premium muddatini tanlang</b>\n";
    
    edit($text, $key);
    exit();
}

if(mb_stripos($data,"premium_")!==false){
    $narx = explode("_",$data)[1];
    $oyi = str_replace("oy",null,$narx);
    $price = file_get_contents("set/$narx.txt");
    $spacec = space($price);
    
    $key = json_encode(['inline_keyboard' =>[
        [['icon_custom_emoji_id' => "6032608126480421344", 'text'=>"👤 O‘zimga", 'callback_data'=>"myselfprem"]],
        [['text'=>$orqa, 'callback_data'=> "premium"]]
    ]]);
    
    $text = "<tg-emoji emoji-id='5771887475421090729'>👤</tg-emoji> <b>Foydalanuvchi nomi</b>\n\n"
        . "<blockquote><tg-emoji emoji-id='5954175920506933873'>👤</tg-emoji>Biz Telegram Premiumni qaysi profilga yuborishimizni aniqlashtirib olishimiz kerak "
        . "\n<tg-emoji emoji-id='5954175920506933873'>👤</tg-emoji>Masalan: @username</blockquote>\n\n"
        . "<tg-emoji emoji-id='5879770735999717115'>👤</tg-emoji> Foydalanuvchi nomini yuboring yoki tugmani bosing:\n";
    
    edit($text, $key);
    step($data);
    exit();
}
if(mb_stripos($step,"premium_")!==false){
    $narx = explode("_",$step)[1];
    $oyi = str_replace("oy",null,$narx);
    $price = file_get_contents("set/$narx.txt");
    $spacec = space($price);
    if($data == "myselfprem"){
        $use = $username;
    }elseif(isset($text)){
        $use = $text;
    }
    $user = clean_username($use ?? '');
    if($user != null){
        step("0");
        mysqli_query($connect,"INSERT INTO premium(`user_id`,`month`,`status`,`price`,`username`,`time`) VALUES ('$cid','$oyi','pending','$price','$user','$sana $time')");
        $last_id = mysqli_insert_id($connect);
        $prie = space($price);
        
        $key = json_encode(['inline_keyboard' =>[
            [['icon_custom_emoji_id' => "5143290574673019778", 'text'=>" Tasdiqlash", 'callback_data'=>"refdanprem=$last_id"]],
            [['text'=>$orqa, 'callback_data'=> "cancelprem=$last_id"]]
        ]]);
        
        $texit = "<tg-emoji emoji-id='5983399041197675256'>👤</tg-emoji> <b>Buyurtma yaratildi</b>\n\n"
            . "<blockquote>◾️Turi: <tg-emoji emoji-id='5789911984283586269'>👤</tg-emoji> Telegram Premium\n"
            . "◾️Username: @$user\n"
            . "◾️Muddati: $oyi oy\n"
            . "◾️ Summa: $prie so'm\n</blockquote>\n"
            . "<tg-emoji emoji-id='5927169041595634481'>👤</tg-emoji>To'lov amalga oshirilgach, buyurtma avtomatik yuboriladi\n";
        
        if(isset($text)){
            send($texit,$key);
            step("0");
            exit();
        }elseif($data == "myselfprem"){
            edit($texit,$key);
            step("0");
            exit();
        }
    }else{
        ans("Sizda username mavjud emas!");
        exit();
    }
}

// ========== PREMIUM API ORQALI SOTIB OLISH (AVTOMATIK) ==========
if(mb_stripos($data,"refdanprem=")!==false){
    $id = explode("=",$data)[1];
    $id = (int)$id;
    if (!order_lock('premium', $id)) { ans("⏳ Premium buyurtma qayta ishlanmoqda, qayta bosmang.", true); exit(); }
    $ox = mysqli_query($connect, "SELECT * FROM premium WHERE id = $id AND status = 'pending'");
    $xx = mysqli_fetch_assoc($ox);
    if (!$xx) { order_unlock('premium', $id); ans("❌ Premium buyurtma topilmadi yoki allaqachon bajarilgan.", true); exit(); }
    $month = $xx['month'];
    $price = $xx['price'];
    $user = $xx['username'];

    if($pul >= $price){
        delete();
        
        // API kalitini o'qish
        $apiKey = trim(file_get_contents("set/fragment_api_key.txt"));
        
        if(empty($apiKey)){
            send("<b>❌ Fragment API sozlanmagan! Admin panelga kirib API kalitni kiriting.</b>", null);
            mysqli_query($connect, "DELETE FROM premium WHERE id = '$id'");
            order_unlock('premium', $id);
            exit();
        }
        
        // FragmentUzAPI class orqali premium sotib olish (AVTOMATIK - tasdiqlash KELMAYDI!)
        $fragment = new FragmentUzAPI($apiKey);
        
        // duration: oylar soni. Fragment odatda 3/6/12 ni qo'llaydi; 1 bo'lsa API o'zi rad etadi.
        $duration = (int)$month;
        $recipientInfo = $fragment->getInfo($user);
        if(!$recipientInfo){
            $error = $fragment->getLastError() ?? "Username Fragment orqali topilmadi";
            bug_log('Premium recipient check failed', ['order_id' => $id, 'user' => $user, 'month' => $month, 'error' => $error]);
            send("<b>❌ Username tekshiruvdan o‘tmadi:</b> " . h($error) . "\n\nUsername to‘g‘riligini tekshiring.", $menu);
            mysqli_query($connect, "DELETE FROM premium WHERE id = '$id'");
            order_unlock('premium', $id);
            step("0");
            exit();
        }
        
        $result = $fragment->buyPremium($user, $duration);
        
        if($result){
            $new = $pul - $price;
            $orid = mysqli_query($connect, "SELECT * FROM premium WHERE status = 'paid'");
            $orderid = mysqli_num_rows($orid);
            $orif = $orderid + 1;

            mysqli_query($connect, "UPDATE users SET money = '$new' WHERE user_id = '$cid'");
            mysqli_query($connect, "UPDATE premium SET order_id = '$orif', status = 'paid' WHERE id = '$id'");

            send("🎉 <b>Premium buyurtma muvaffaqiyatli bajarildi!</b>\n\n🆔 Buyurtma ID: #$orif\n💎 $month oylik Premium @$user ga yuborildi\n💰 Pul yechildi: $price so'm\n✨ Foydalanganingiz uchun rahmat! 🪐", null);

            bot('sendMessage', [
                'chat_id' => $payouts,
                'parse_mode' => 'HTML',
                'text' => "💎 <b>Premium buyurtma bajarildi:</b>\n🆔 Buyurtma ID: #$orif\n🔎 Nikneym: <a href='tg://user?id=$cid'>$name</a>\n📅 Muddat: $month oylik\n💵 Narxi: $price so'm 🏷️\n✅ Status: confirmed"
            ]);

            order_unlock('premium', $id);
            step("0");
            exit();
        } else {
            $error = $fragment->getLastError() ?? "Noma'lum xatolik";
            send("<b>❌ Xatolik: $error</b>\n\n1. API kalitni tekshiring\n2. Balans yetarlimi tekshiring\n3. Username to'g'riligini tekshiring", null);
            send($start, $menu);
            mysqli_query($connect, "DELETE FROM premium WHERE id = '$id'");
            order_unlock('premium', $id);
            step("0");
            exit();
        }
    } else {
        $key = json_encode(['inline_keyboard' => [
            [['text' => "💵 Hisobni to‘ldirish", 'callback_data'=>"topup"]],
            [['text' => $orqa, 'callback_data'=>"start"]]
        ]]);
        edit("❌ <b>Hisobingizda mablag‘ yetarli emas</b>", $key);
        mysqli_query($connect, "DELETE FROM premium WHERE id = '$id'");
        order_unlock('premium', $id);
        exit();
    }
}

if ($data == "referal" and joinchat($cid) == true){
    delete();
    $key = json_encode(['inline_keyboard' => [
        [['icon_custom_emoji_id' => "5440662337742722595",'text' => " Havolani ulashish", 'url' => "https://t.me/share/url/?url=https://t.me/$bot?start=$cid"]],
        [['icon_custom_emoji_id' => "5438380537582478907",'text'=>" TOP foydalanuvchilar",'callback_data'=>"top20"]],
        [['icon_custom_emoji_id' => "5440735356481724855",'text'=>"💎 Haftalik konkurs",'callback_data'=>"rkon"]],
        [['text'=> $orqa,'callback_data'=>"start"]]
    ]]);
    sendp("https://t.me/qora_tanli/19",
        "🖇 <b>Sizning referal havolangiz:</b>\n
<code>https://t.me/$bot?start=$cid</code>\n
♻️ Sizning referallaringiz: <b>$ref ta</b>

Sizga har bir taklif qilgan 👤 1 ta referalingiz uchun $refpay so'm

👤 <b>ID raqam:</b> <code>$cid</code>", $key);
    exit();
}

if (mb_stripos($text, "/start ") !== false and $type == "private") {
    $refid = explode(" ", $text);
    $refid = $refid[1];
    if (is_numeric($refid) == true) {
        if ($refid == $cid) {
            send($start, $menu);
            exit();
        } else {
            if (mb_stripos($user_id, $cid) !== false) {
                send($start, $menu);
                exit();
            } else {
                bot('SendMessage',[
                    'chat_id'=>$umidjon,
                    'text'=>"<b><a href='tg://user?id=$refid'>".getName($refid)."</a></b> da yangi taklif: <b><a href='tg://user?id=$cid'>$name</a></b>\n
<code>$refid</code> -> <code>$cid</code>",
                    'parse_mode'=>'html'
                ]);
                mysqli_query($connect, "UPDATE users SET refid = '$refid' WHERE user_id = '$cid'");
                if ($kanal != null) {
                    bot('SendMessage', [
                        'chat_id' => $refid,
                        'text' => "👤 Sizda yangi <a href='tg://user?id=".$cid."'>referal</a> mavjud. Referalingiz to‘liq ro‘yhatdan o‘tsa ".$refpay." so‘m olasiz!",
                        'parse_mode' => 'html',
                    ]);
                    file_put_contents("caches/$cid.id", $refid);
                    file_put_contents("caches/$cid.txt", $refid);
                    $odam = mysqli_query($connect, "SELECT * FROM users WHERE user_id = $refid");
                    $refk = mysqli_fetch_assoc($odam);
                    $ref = $refk['ref'];
                    $b = $ref + 1;
                    mysqli_query($connect, "UPDATE users SET ref = $b WHERE user_id = $refid");
                    if (joinchat($cid) == true) {
                        send($start, $check);
                    }
                    exit();
                } else {
                    $odam = mysqli_query($connect, "SELECT * FROM users WHERE user_id = $refid");
                    $xox = mysqli_fetch_assoc($odam);
                    $ref = $xox['ref'];
                    $pul = $xox['money'];
                    $b = $ref + 1;
                    $bx = $pul + $refpay;
                    mysqli_query($connect, "UPDATE users SET money = '$bx', ref = '$b' WHERE user_id = '$refid'");
                    send($start, $menu);
                    bot('SendMessage', [
                        'chat_id' => $refid,
                        'text' => "👤 Sizda yangi <a href='tg://user?id=".$cid."'>referal</a> mavjud. Siz ".$refpay." so‘m oldingiz!",
                        'parse_mode' => 'html',
                    ]);
                    exit();
                }
            }
        }
    } else {
        $rew = mysqli_fetch_assoc(mysqli_query($connect, "SELECT*FROM `cheques` WHERE `cheque` = '$refid'"));
        $money = $rew['money'];
        $status = $rew['status'];
        $newmoney = $money + $pul;
        if ($rew) {
            if ($status == "on") {
                mysqli_query($connect, "UPDATE cheques SET status = 'off', user = '$cid' WHERE cheque = '$refid'");
                mysqli_query($connect, "UPDATE users SET money = '$newmoney' WHERE user_id = '$cid'");
                send("✅ Siz <b>$money</b> so‘mlik chekni aktivlashtirdingiz!", null);
                $adm = mysqli_query($connect, "SELECT * FROM `admins` ");
                $his = date('H:i:s');
                while($mem = mysqli_fetch_assoc($adm)){
                    $umid = $mem['user_id'];
                    bot('sendMessage',[
                        'text'=>"✅ <b><a href='tg://user?id=$cid'>$name</a></b> foydalanuvchi <b>$money</b> so‘mlik chekni aktivlashtirdi!\n\n⏰ <b>Ishlatilgan vaqt:</b> $his",
                        'chat_id'=>$umid,
                        'parse_mode'=>'html'
                    ]);
                }
                exit();
            } else {
                reaction("👍");
                send("😞 Chek avvalroq ishlatilgan", null);
                exit();
            }
        } else {
            send($start, $menu);
            exit();
        }
    }
}



if($data == "history" and joinchat($cid)==true){
    $mes = "";
    $yukla = mysqli_query($connect, "SELECT * FROM `number` WHERE `user_id` = '$cid' ORDER BY id DESC LIMIT 10");
    while($us = mysqli_fetch_assoc($yukla)){
        $order_id = $us['id'];
        $number = $us['number'];
        $date = $us['date'];
        $time = $us['time'];
        $price = $us['price'];
        $country = $us['country'];
        $country_query = $connect->query("SELECT * FROM auto_country WHERE code = '{$country}'");
        $cn = $country_query->fetch_assoc();
        $countryz = $cn['name'];
        $mes .= "🆔 <b>ID:</b> $order_id | <code>$number</code> | <b>$countryz</b>
💸 <b>Narx:</b> $price so‘m | <b>$date-$time</b>\n\n";
    }
    $orders = json_encode([
        'inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"start"]]
        ]]);
    $result = mysqli_query($connect, "SELECT * FROM `number` WHERE `user_id` = '$cid'");
    $row = mysqli_fetch_assoc($result);
    if($row){
        $soni = mysqli_num_rows($result);
        edit("<b>️📊 Jami buyurtmalaringiz soni - $soni ta
🗒️ Ohirgi 10 ta buyurtmangiz:</b>\n
$mes",$orders);
        exit();
    }else{
        ans("Siz raqam sotib olmagansiz!");
        exit;
    }
}

if ($data == "check") {
    if (isset($username)) {
        delete();
        if (joinchat($cid) == true) {
            $refid = file_get_contents("caches/$cid.txt");
            $cid3 = file_get_contents("caches/$cid.id");
            if ($refid != $cid3) {
                send($start, $menu);
                exit();
            } else {
                $cash = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$cid3'");
                $rew = mysqli_fetch_assoc($cash);
                $balans = $rew['money'];
                $b = $balans + $refpay;
                mysqli_query($connect, "UPDATE users SET money = '$b' WHERE user_id = '$refid'");
                send($start, $menu);
                bot('SendMessage', [
                    'chat_id' => $cid3,
                    'text' => "💳 Sizning referalingiz registratsiyadan o‘tdi va sizga <b>".$refpay." so‘m</b> berildi",
                    'parse_mode' => 'html',
                ]);
                $konus = file_get_contents("ref/$cid3.txt");
                $yangs = $konus + 1;
                file_put_contents("ref/$cid3.txt",$yangs);
                unlink("caches/$cid.txt");
                unlink("caches/$cid.id");
                exit();
            }
        }
    } else {
        ans("❗️ Botdan foydalanish uchun foydalanuvchi nomingiz bo‘lishi kerak! (username)");
        exit();
    }
}

if ($data === "top20") {
    delete();
    $query = "SELECT * FROM `users` ORDER BY CAST(`ref` AS UNSIGNED) DESC LIMIT 20";
    $result = mysqli_query($connect, $query);
    if (!$result || mysqli_num_rows($result) === 0) {
        ans("🚫 Mavjud emas, bazada xatolik yuz berdi!");
        exit();
    }
    $text = "🏆 TOP 20 - natijalar\n\n";
    $number = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        if ($number === 1) {
            $emoji = "🥇";
        } elseif ($number === 2) {
            $emoji = "🥈";
        } elseif ($number === 3) {
            $emoji = "🥉";
        } else {
            $emoji = "🏅";
        }
        $user_id = $row['user_id'];
        $ref_raw = $row['ref'];
        preg_match('/\d+/', $ref_raw, $matches);
        $ref_count = isset($matches[0]) ? (int)$matches[0] : 0;
        $name = getName($user_id);
        if (empty($name)) {
            $name = "Foydalanuvchi";
        }
        $safe_name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $text .= "$emoji $number ] - <a href=\"tg://user?id=$user_id\">$safe_name</a> - $ref_count ta\n";
        $number++;
    }

    $text .= "\n";
    send($text, null);
    exit();
}

if($data == "rkon" or $text == "/konkurs" or $text == "/start konkurs"){
    if(joinchat($cid)==true){
        if($konkurs == "off"){
            ans("⏳ Referal konkurs mavjud emas!\nAdministratorlar tez orada qo‘shishadi :)");
            step("0");
            exit();
        }else{
            delete();
            $gey = file_get_contents("ref/$cid.txt");
            if($gey == null){ $gey = "0"; }
            $key = json_encode(['inline_keyboard'=>[
                [['text'=>"🏆 REYTING TOP - 10",'callback_data'=>"ratingref"]],
            ]]);
            $qogan = explode(" ",$konkurs)[0];
            $qoma = explode(" ",$konkurs)[1];
            $qolgan = sana($sana,$qogan);

            $start = new DateTime("$sana $soat");
            $end = new DateTime("$qogan $qoma");
            $diff = $start->diff($end);
            $kuni = $diff->days;
            $soati = $diff->h;
            $minuti = $diff->i;
            send("🚀 <b>Referal konkurs davom etmoqda!
👥 Sizning referallaringiz:</b> $gey ta\n
📆 Tugash sanasi: <b>$qogan</b>
⏰ Tugash vaqti: <b>$qoma</b>
————————————————
⏳️ <b>Qolgan:</b> $kuni-kun, $soati-soat, $minuti-min
————————————————
✅ <b>Konkurs haqida maʼlumotlar:</b>\n
$konkursinfo",$key);
        }
        exit();
    }
}

if($data == "ratingref"){
    $a = referal(10);
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>"Referal havolangiz", 'copy_text' => ['text' => "https://t.me/$bot?start=$cid"]]],
        [['icon_custom_emoji_id' => "5278702045883292456",'text' => " Orqaga",'callback_data'=>"rkon"]],
    ]]);
    edit("<b>TOP 10 Referallar ro‘yxati</b>\n
$a",$key);
    exit();
}

if ($text == "/admin" or $data == 'panel') {
    if ($admins) {
        reaction("👨‍💻");
        if ($data) {
            delete();
        }
        $ping = sys_getloadavg()[2];
        send("<b>⚙ Administrator paneli:\n
💡 PING:</b> <code>$ping</code> MS\n
Siz tizimni boshqarish huquqiga egasiz!
Iltimos, ehtiyorkorlik bilan ishlang",$panel);
        step('0');
        exit();
    }
}

if($data == "stat" and $admins){
    $user = mysqli_query($connect, "SELECT * FROM users");
    $users = mysqli_num_rows($user);
    $user0 = mysqli_query($connect, "SELECT * FROM users WHERE date = '$sana'");
    $users0 = mysqli_num_rows($user0);
    $active = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM users WHERE status = '1'"));
    $deactive = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM users WHERE status = '0'"));
    $sqx = mysqli_query($connect,"SELECT SUM(stars) AS total_money FROM orders WHERE status = 'paid'");
    $rowx = mysqli_fetch_assoc($sqx);
    $solve = $rowx['total_money'] ?? 0;
    $sqx7 = mysqli_query($connect,"SELECT SUM(stars) AS total_money7 FROM orders WHERE status = 'paid' AND time = '$sana'");
    $rowx7 = mysqli_fetch_assoc($sqx7);
    $solve7 = $rowx7['total_money7'] ?? 0;
    $sql = mysqli_query($connect,"SELECT SUM(price) AS total_price FROM orders WHERE status = 'paid'");
    $row = mysqli_fetch_assoc($sql);
    $totalPrice = $row['total_price'] ?? 0;
    $sqo = mysqli_query($connect,"SELECT SUM(amount) AS total_amount FROM auto_payments WHERE status = 'success'");
    $rowo = mysqli_fetch_assoc($sqo);
    $totalAmount = $rowo['total_amount'] ?? 0;

    $sqx = mysqli_query($connect,"SELECT SUM(money) AS total_money FROM users");
    $rowx = mysqli_fetch_assoc($sqx);
    $totalMoney = $rowx['total_money'] ?? 0;

    $sql = mysqli_query($connect,"SELECT SUM(price) AS total_price FROM orders WHERE time = '$sana' AND status = 'paid'");
    $row = mysqli_fetch_assoc($sql);
    $totalPrice2 = $row['total_price'] ?? 0;

    $sqo = mysqli_query($connect,"SELECT SUM(amount) AS total_amount FROM auto_payments WHERE status = 'success' AND success_time = '$sana'");
    $rowo = mysqli_fetch_assoc($sqo);
    $totalAmount2 = $rowo['total_amount'];

    edit("<tg-emoji emoji-id=\"5460677173104885788\">👋</tg-emoji> <b>Foydalanuvchilar statistikasi:</b>
• Jami foydalanuvchilar: <b>$users ta</b>
• Aktiv a'zolar: <b>$active ta</b>
• Bloklaganlar: <b>$deactive ta</b>
• Bugun kelgan: <b>$users0 ta\n
<tg-emoji emoji-id=\"5442862005243358868\">👋</tg-emoji> Sotilgan yulduzlar</b>
• Umumiy sotilgan: <b>$solve Stars</b>
• Bugun sotilgan: <b>$solve7 Stars</b>\n
<tg-emoji emoji-id=\"5278467510604160626\">👋</tg-emoji> <b>Pul aylanmasi:</b>
• Jami ishlatilgan: <b>".space($totalPrice)." soʻm</b>
• Jami kiritilgan: <b>".space($totalAmount)." soʻm</b>

<tg-emoji emoji-id=\"5274055917766202507\">👋</tg-emoji> <b>Kunlik aylanma statistikasi</b>
• Bugun sotilgan: <b>".space($totalPrice2)." so‘m</b>
• Bugun kiritilgan: <b>".space($totalAmount2)." so‘m</b>

<tg-emoji emoji-id=\"5278467510604160626\">👋</tg-emoji> <b>Mavjud jami pullar:</b> ".space($totalMoney)." so‘m",$backpanel);
    step("0");
    exit();
}

if ($data == 'settings') {
    $key = json_encode(['inline_keyboard' => [
        [['text' => "1 - [⚙️]", 'callback_data' => "change_refpay"], ['text' => "2 - [⚙️]", 'callback_data' => "change_payouts"],['text'=>"3 - [⚙️]", 'callback_data' => "prcprm=50"]],
        [['text'=>"💎 1 Oy",'callback_data'=>"prcprm=oy1"],['text'=>"💎 3 Oy",'callback_data'=>"prcprm=oy3"]],
        [['text'=>"💎 6 Oy",'callback_data'=>"prcprm=oy6"],['text'=>"💎 12 Oy",'callback_data'=>"prcprm=oy12"]],
        [['text' => $orqa, 'callback_data' => "panel"]],
    ]]);
    if ($admins) {
        $star_display = number_format($star, 0, '.', ' ');
        $refpay_display = number_format($refpay, 0, '.', ' ');
        $oy1_display = number_format($oy1, 0, '.', ' ');
        $oy3_display = number_format($oy3, 0, '.', ' ');
        $oy6_display = number_format($oy6, 0, '.', ' ');
        $oy12_display = number_format($oy12, 0, '.', ' ');
        
        edit("<b>✉️ Joriy qiymatlar:</b>\n
<b>1.</b> Referal narxi - $refpay_display soʻm
<b>2.</b> Isbot kanali - $payouts
<b>3.</b> ⭐ Stars narxi (1 dona) - $star_display soʻm\n
⭐ <b>Premium 1-oy:</b> $oy1_display so‘m
⭐ <b>Premium 3-oy:</b> $oy3_display so‘m
⭐ <b>Premium 6-oy:</b> $oy6_display so‘m
⭐ <b>Premium 12-oy:</b> $oy12_display so‘m\n
— <i>O‘zgartirish uchun tanlang:</i>", $key);
    }
}

if (mb_stripos($data, "prcprm=") !== false) {
    edit("<b>Yangi qiymatni kiriting:</b>", $backpanel);
    step($data);
    exit();
}

if (mb_stripos($step, "prcprm=") !== false) {
    $ex = explode("=", $step)[1];
    send("<b>O‘zgartirildi!</b>", $backpanel);
    put("set/$ex.txt", $text);
    step('0');
    exit();
}

if (mb_stripos($data, "change_") !== false) {
    edit("<b>Yangi qiymatni kiriting:</b>", $backpanel);
    step($data);
    exit();
}

if (mb_stripos($step, "change_") !== false) {
    $ex = explode("_", $step)[1];
    send("<b>O‘zgartirildi!</b>", $backpanel);
    put("admin/$ex.txt", $text);
    step('0');
    exit();
}

if ($data == 'infouser') {
    if ($admins) {
        delete();
        send("👉 Foydalanuvchi ID raqamini kiriting:", $backpanel);
        step("infouser");
        exit();
    }
}

if ($step == 'infouser' or mb_stripos($data, "checkid=") !== false) {
    if ($admins) {
        if ($step == 'infouser') {
            $chat = $text;
        } elseif ($data) {
            $chat = str_replace("checkid=", null, $data);
        }
        $id = bot('getChat', ['chat_id' => $chat])->result->id;
        $ism = bot('getChat', ['chat_id' => $chat])->result->first_name;
        $user = bot('getChat', ['chat_id' => $chat])->result->username;
        $res = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$id'");
        $a = mysqli_fetch_assoc($res);
        if ($a) {
            $date = $a['date'];
            $status = $a['status'];
            $refid = $a['refid'];
            $ban = $a['ban'];
            $money = $a['money'] ?? '0';
            $sqx = mysqli_query($connect,"SELECT SUM(stars) AS total_money FROM orders WHERE status = 'paid' AND user_id = '$id'");
            $rowx = mysqli_fetch_assoc($sqx);
            $solve = $rowx['total_money'] ?? 0;
            $kun = sana($sana, $date);
            if ($ban == '1') {
                $bani = "✅ Bandan chiqarish";
            } else {
                $bani = "🔴 Banlash";
            }
            $key = json_encode(['inline_keyboard' => [
                [['text' => "$bani", 'callback_data' => "ban=$id"]],
                [['text' => "➕ Pul qo‘shish", 'callback_data' => "add=$id"], ['text' => "✏️ Balansni o‘zgartirish", 'callback_data' => "reduce=$id"]],
                [['text' => "✉️ Xabar yuborish", 'callback_data' => "sendmsg=$id"]],
                [['text' => $orqa, 'callback_data' => "panel"]],
            ]]);
            if ($status == '1') {
                $sta = '✅';
            } else {
                $sta = '❌';
            }
            if (is_numeric($refid) == true) {
                $x = "<a href='tg://user?id=".$refid."'>$refid</a>";
            } else {
                $x = "Yo‘q";
            }
            send("<b>👤 <a href='tg://user?id=".$id."'>Foydalanuvchi</a> haqida ma’lumot:

🆔 ID: <code>$id</code>
✏ Ismi:</b> $ism
✏ <b>Username:</b> @$user
🗒 <b>Botdagi kunlari:</b> $kun
📝 <b>Status:</b> $sta
——————————————————————
💳 <b>BALANS</b>
◽ Olingan starsi: ".$solve." ta
◽ Asosiy balans: ".$money." so‘m", $key);
            step('0');
            exit();
        } else {
            send("Foydalanuvchi topilmadi", $menu);
            step('0');
            exit();
        }
    }
}

if(mb_stripos($data,"history=")!==false){
    $mes = "";
    $cido = explode("=",$data)[1];
    $yukla = mysqli_query($connect, "SELECT * FROM `number` WHERE `user_id` = '$cido' ORDER BY id DESC LIMIT 10");
    while($us = mysqli_fetch_assoc($yukla)){
        $order_id = $us['id'];
        $number = $us['number'];
        $date = $us['date'];
        $time = $us['time'];
        $price = $us['price'];
        $country = $us['country'];
        $country_query = $connect->query("SELECT * FROM auto_country WHERE code = '{$country}'");
        $cn = $country_query->fetch_assoc();
        $countryz = $cn['name'];
        $mes .= "🆔 $order_id | $number | $countryz
💸 Narx: $price so‘m | $date-$time\n\n";
    }
    $orders = json_encode([
        'inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"checkid=$cido"]]
        ]]);
    $result = mysqli_query($connect, "SELECT * FROM `number` WHERE `user_id` = '$cid'");
    $row = mysqli_fetch_assoc($result);
    if($row){
        $soni = mysqli_num_rows($result);
        edit("<b>🗒️ Buyurtmalari soni: $soni ta</b>\n
$mes",$orders);
        exit();
    }else{
        ans("Foydalanuvchi raqam sotib olmagan!");
        exit;
    }
}

if (mb_stripos($data, "ban=") !== false) {
    $id = explode("=", $data)[1];
    $res = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$id'");
    $a = mysqli_fetch_assoc($res);
    $ban = $a['ban'];
    if ($ban == '1') {
        $put = '0';
        $text = "🟢 Foydalanuvchi bandan olindi!";
    } else {
        $put = '1';
        $text = "🔴 Foydalanuvchi banlandi!";
    }
    mysqli_query($connect, "UPDATE users SET ban = '$put' WHERE user_id = '$id'");
    $key = json_encode([
        'inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"checkid=$id"]]
        ]]);
    edit($text, $key);
    exit();
}

if (mb_stripos($data, "add=") !== false) {
    $id = explode("=", $data)[1];
    $key = json_encode([
        'inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"checkid=$id"]]
        ]]);
    edit("<b>Qiymatni kiriting:</b>", $key);
    step($data);
    exit();
}

if (mb_stripos($data, "reduce=") !== false) {
    $id = explode("=", $data)[1];
    $key = json_encode([
        'inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"checkid=$id"]]
        ]]);
    edit("<b>O’zgartirish uchun summani kiriting:</b>", $key);
    step($data);
    exit();
}

if (mb_stripos($step, "add=") !== false) {
    $id = explode("=", $step)[1];
    if (is_numeric($text) == true) {
        $ax = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$id'");
        $ex = mysqli_fetch_assoc($ax);
        $money = $ex['money'];
        $new = $money + $text;
        mysqli_query($connect, "UPDATE users SET money = '$new' WHERE user_id = '$id'");
        $key = json_encode([
            'inline_keyboard'=>[
                [['text'=>$orqa,'callback_data'=>"checkid=$id"]]
            ]]);
        send("💳 Foydalanuvchi <b>$id</b> balansi <b>".$text." so‘m</b>ga to‘ldirildi!", $key);
        bot('sendMessage', ['chat_id' => $id, 'parse_mode' => 'html',
            'text' => "💳 Sizning balansingiz <b>".$text." so‘m</b>ga to‘ldirildi!"]);
        step('0');
        exit();
    }
}

if (mb_stripos($step, "reduce=") !== false) {
    $id = explode("=", $step)[1];
    if (is_numeric($text) == true) {
        mysqli_query($connect, "UPDATE users SET money = '$text' WHERE user_id = '$id'");
        send("💳 Foydalanuvchi <b>$id</b> balansi <b>".$text." so‘m</b>ga o‘zgartirildi", null);
        bot('sendMessage', ['chat_id' => $id, 'parse_mode' => 'html',
            'text' => "💳 Sizning balansingiz <b>".$text." so‘m</b>ga o‘zgartirildi!"]);
        step('0');
        exit();
    }
}

if (mb_stripos($data, "sendmsg=") !== false) {
    if ($admins) {
        delete();
        $key = json_encode([
            'inline_keyboard'=>[
                [['text'=>$orqa,'callback_data'=>"checkid=$id"]]
            ]]);
        send("<b>👉 Xabar matnini kiriting:</b>", $key);
        step($data);
        exit();
    }
}

if (mb_stripos($step, "sendmsg=") !== false) {
    $id = explode("=", $step)[1];
    $key = json_encode([
        'inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"checkid=$id"]]
        ]]);
    bot('CopyMessage', [
        'chat_id' => $id,
        'from_chat_id' => $cid,
        'message_id' => $mid
    ]);
    send("✅ <b>Xabaringiz yuborildi!</b>", $key);
    step('0');
    exit();
}

if (mb_stripos($data, "refs=") !== false) {
    $top = "";
    $id = explode("=", $data)['1'];
    $sql = "SELECT * FROM users WHERE refid = '$id' LIMIT 0,50";
    $res = mysqli_query($connect, $sql);
    while ($row = mysqli_fetch_assoc($res)) {
        $usid = $row['user_id'];
        $us = bot('getChat', ['chat_id' => $usid])->result->username;
        if ($us) {
            $use = "@$us";
        } else {
            $use = 'null';
        }
        $top .= "<code>$usid</code> - $use\n";
    }
    $ids = explode("\n", "\n$top");
    $soi = substr_count($top, "\n");
    $soni = $soi;
    $text = "";
    foreach ($ids as $id) {
        $keyboards = [];
        for ($i = 1; $i <= $soni; $i++) {
            $title = str_replace("\n", "", $ids[$i]);
            $text .= "<b>$i)</b> ".$ids[$i]."\n";
        }
    }
    $id = explode("=", $data)['1'];
    $r1 = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$id'");
    $r2 = mysqli_fetch_assoc($r1);
    $refs = $r2['ref'];
    edit("<b>📑 Referallarining ro‘yhati
👤 Jami referallar:</b> 50/".$refs."\n\n$text", json_encode(['inline_keyboard' => [
        [['text' => "🔚", 'callback_data' => "back=0=$id"], ['text' => "🔜", 'callback_data' => "next=50=$id"]],
        [['text' => "⛔ Yopish", 'callback_data' => "checkid=$id"]]]]));
    exit();
}

if (mb_stripos($data, "next=") !== false) {
    $top = "";
    $ex = explode("=", $data);
    $explode = $ex[1];
    $explode1 = $explode + 50;
    $id = $ex[2];
    $r1 = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$id'");
    $r2 = mysqli_fetch_assoc($r1);
    $refs = $r2['ref'];
    $sql = "SELECT * FROM users WHERE refid = '$id' LIMIT $explode,50";
    $res = mysqli_query($connect, $sql);
    while ($row = mysqli_fetch_assoc($res)) {
        $usid = $row['user_id'];
        $us = bot('getChat', ['chat_id' => $usid])->result->username;
        if ($us) {
            $use = "@$us";
        } else {
            $use = 'null';
        }
        $top .= "<code>$usid</code> - $use\n";
    }
    $ids = explode("\n", "\n$top");
    $soi = substr_count($top, "\n");
    $soni = $soi;
    $text = "";
    foreach ($ids as $id) {
        for ($i = 1; $i <= $soni; $i++) {
            $title = str_replace("\n", "", $ids[$i]);
            $text .= "<b>$i)</b> ".$ids[$i]."\n";
        }
    }
    edit("<b>📑 Referallarining ro‘yhati
👤 Jami referallar:</b> ".$explode1."/".$refs."\n\n$text", json_encode(['inline_keyboard' => [
        [['text' => "🔚", 'callback_data' => "back=$explode=$id"], ['text' => "🔜", 'callback_data' => "next=$explode1=$id"]],
        [['text' => "⛔ Yopish", 'callback_data' => "checkid=$id"]]]]));
    exit();
}

if (mb_stripos($data, "back=") !== false) {
    $ex = explode("=", $data);
    $explode = $ex[1];
    $id = $ex[2];
    if ($ex[1] == '0') {
        ans("Siz birinchi sahifada turibsiz!");
        exit();
    } else {
        $top = "";
        $explode1 = $explode - 50;
        $sql = "SELECT * FROM users WHERE refid = '$id' LIMIT $explode1,50";
        $res = mysqli_query($connect, $sql);
        while ($row = mysqli_fetch_assoc($res)) {
            $usid = $row['user_id'];
            $us = bot('getChat', ['chat_id' => $usid])->result->username;
            if ($us) {
                $use = "@$us";
            } else {
                $use = 'null';
            }
            $top .= "<code>$usid</code> - $use\n";
        }
        $ids = explode("\n", "\n$top");
        $soi = substr_count($top, "\n");
        $soni = $soi;
        $text = "";
        foreach ($ids as $id) {
            for ($i = 1; $i <= $soni; $i++) {
                $title = str_replace("\n", "", $ids[$i]);
                $text .= "<b>$i)</b> ".$ids[$i]."\n";
            }
        }
        $id = $ex[2];
        $r1 = mysqli_query($connect, "SELECT * FROM users WHERE user_id = '$id'");
        $r2 = mysqli_fetch_assoc($r1);
        $refs = $r2['ref'];
        edit("<b>📑 Referallarining ro‘yhati
👤 Jami referallar:</b> ".$explode."/".$refs."\n\n$text", json_encode(['inline_keyboard' => [
            [['text' => "🔚", 'callback_data' => "back=$explode1=$id"], ['text' => "🔜", 'callback_data' => "next=$explode=$id"]],
            [['text' => "⛔ Yopish", 'callback_data' => "checkid=$id"]]]]));
        exit();
    }
}

if($data == "payouts"){
    if($admins){
        $mes = "";
        $kb = [];
        $rew = mysqli_query($connect,"SELECT*FROM `premium` WHERE `status` = 'paid'");
        while($us = mysqli_fetch_assoc($rew)){
            $id = $us['id'];
            $orderid = $us['order_id'];
            $user_id = $us['user_id'];
            $month = $us['month'];
            $price = $us['price'];
            $username = $us['username'];
            $kb[]=['text'=>"🆔 $id",'callback_data'=>"premout=$id"];
            $mes .= "💎 <b>#$orderid)</b> Premium ".$month." oylik - <a href='tg://user?id=".$user_id."'>$user_id</a>\n";
        }
        $keyboard2 = array_chunk($kb, 3);
        $keyboard2[] = [['text'=>$orqa,'callback_data'=>"panel"]];
        $key = json_encode([
            'inline_keyboard'=>$keyboard2
        ]);
        $row = mysqli_fetch_assoc($rew);
        $ns = mysqli_num_rows($rew);
        if($ns > 0){
            edit("<b>📤 Tekshirilmagan to’lovlar ro‘yhati:</b>\n
$mes",$key);
            exit();
        }else{
            ans("👍 Premium olish uchun so‘rov yo‘q");
            exit();
        }
    }
}

if(mb_stripos($data,"premout=")!==false){
    if($admins){
        $id = explode("=",$data)[1];
        $rew = mysqli_query($connect,"SELECT*FROM `premium` WHERE `id` = '$id'");
        $row = mysqli_fetch_assoc($rew);
        $id = $row['id'];
        $user = $row['user_id'];
        $month = $row['month'];
        $price = $row['price'];
        $username = $row['username'];
        $time = $row['time'];
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"✅ Premium yubordim",'callback_data'=>"yespremium=$id"]],
            [['text'=>"❌ Rad etish",'callback_data'=>"nopremium=$id"]],
            [['text'=>$orqa,'callback_data'=>"payouts"]]
        ]]);
        edit("👤 <a href='tg://user?id=".$user."'>Foydalanuvchi</a> (<code>$user</code>):

• <b>Premium:</b> ".$month." oylik
• <b>Yuborish:</b> @$username
• <b>Narxi:</b> $price
• <b>Kelgan vaqt:</b> $time",$key);
        exit();
    }
}

if(mb_stripos($data,"yespremium=")!==false){
    $ex = explode("=", $data);
    $order = $ex[1];
    $select = mysqli_query($connect,"SELECT*FROM premium WHERE id = '$order'");
    $row = mysqli_fetch_assoc($select);
    $user_id = $row['user_id'];
    $oy = $row['month'];
    $price = $row['price'];
    $ega = $row['username'];
    $orderid = $row['order_id'];
    edit("✅ <b>Premium uchun soʻrov tasdiqlandi</b>",$backpanel);
    bot('sendMessage',[
        'chat_id'=>$payouts,
        'parse_mode'=>'html',
        'text'=>"💎 <b>TG Premium olindi:</b>
Order ID: #$orderid 🆔
Tarif: $oy oylik Premium
Nickname: <a href='tg://user?id=$user_id'>".getName($user_id)."</a>
Price: $price so‘m
Status: ✅ Completed"
    ]);
    bot('sendMessage',[
        'chat_id'=>$user_id,
        'parse_mode'=>'html',
        'text'=>"💎 <b>Sizning buyurtmangiz bajarildi!

📊 Xizmat: $oy oylik Premium
💳 Narxi: $price so‘m

✅ Qabul qilib oldi: @$ega

🚀 @$bot xizmatidan foydalanganingiz uchun tashakkur!</b>"
    ]);
    mysqli_query($connect,"UPDATE premium SET status = 'completed' WHERE id = '$order'");
    exit();
}

if(mb_stripos($data,"nopremium=")!==false){
    $ex = explode("=", $data);
    $order = $ex[1];
    $select = mysqli_query($connect,"SELECT*FROM premium WHERE id = '$order'");
    $row = mysqli_fetch_assoc($select);
    $user_id = $row['user_id'];
    $oy = $row['month'];
    $price = $row['price'];
    $usr = $row['username'];
    delete();
    send("❌ Foydalanuvchi <a href='tg://user?id=$user_id'>".getName($user_id)."</a> (<code>$user_id</code>) buyurtmasi bekor qilindi!", $menu);
    bot('sendMessage',[
        'chat_id'=>$user_id,
        'parse_mode'=>'html',
        'text'=>"❌ Sizning $oy oylik Telegram Premium uchun yuborgan buyurtmangiz rad etildi!"
    ]);
    mysqli_query($connect,"UPDATE premium SET status = 'canceled' WHERE id = '$order'");
    exit();
}

if ($data == 'channels') {
    if ($admins) {
        if ($kanalstatus == "on") {
            $status = "✅ Yoqilgan";
            $but = "❌ Uzib qo‘yish";
        } else {
            $status = "❌ O‘chirilgan";
            $but = "✅ Yoqib qo‘yish";
        }
        if (mb_stripos($kanal, "@") !== false) {
            $chan = "\n".$kanal;
        } else {
            $chan = "Yo‘q";
        }
        $key = json_encode(['inline_keyboard' => [
            [['text' => "$but", 'callback_data' => "ch"]],
            [['text' => "📢 Kanal o‘chirish", 'callback_data' => "delchannel"], ['text' => "📢 Kanal qo‘shish", 'callback_data' => "addchannel"]],
            [['text' => $orqa, 'callback_data' => "panel"]],
        ]]);
        edit("<b>🚸 Majburiy kanalga obuna
ℹ️ Status:</b> $status
📢 <b>Kanallar:</b> $chan", $key);
        step('0');
        exit();
    }
}

if ($data == "ch") {
    delete();
    if ($kanalstatus == "on") {
        $status = "❌ O‘chirilgan";
        $call = "off";
        $but = "✅ Yoqib qo‘yish";
    } else {
        $status = "✅ Yoqilgan";
        $call = "on";
        $but = "🚫 Uzib qo‘yish";
    }
    if (mb_stripos($kanal, "@") !== false) {
        $chan = "\n".$kanal;
    } else {
        $chan = "Yo‘q";
    }
    $key = json_encode(['inline_keyboard' => [
        [['text' => "$but", 'callback_data' => "ch"]],
        [['text' => "📢 Kanal o‘chirish", 'callback_data' => "delchannel"], ['text' => "📢 Kanal qo‘shish", 'callback_data' => "addchannel"]],
        [['text' => $orqa, 'callback_data' => "panel"]],
    ]]);
    send("<b>🚸 Majburiy kanalga obuna
ℹ️ Status:</b> $status
📢 <b>Kanallar:</b> $chan", $key);
    put("admin/kstatus.txt", $call);
    exit();
}

if ($data == "delchannel") {
    if (mb_stripos($kanal, "@") !== false) {
        ans("Kanallar o‘chirildi!");
        unlink('admin/kanal.txt');
        if ($kanalstatus != "on") {
            $status = "❌ Uzib qo‘yilgan";
            $but = "✅ Yoqib qo‘yish";
        } else {
            $status = "✅ Yoqilgan";
            $but = "🚫 Uzib qo‘yish";
        }
        $key = json_encode(['inline_keyboard' => [
            [['text' => "$but", 'callback_data' => "ch"]],
            [['text' => "📢 Kanal o‘chirish", 'callback_data' => "delchannel"], ['text' => "📢 Kanal qo‘shish", 'callback_data' => "addchannel"]],
            [['text' => $orqa, 'callback_data' => "panel"]],
        ]]);
        edit("<b>🚸 Majburiy kanalga obuna:
ℹ️ Status:</b> $status
📢 <b>Kanallar:</b> Mavjud emas", $key);
        exit();
    } else {
        ans("Kanallar mavjud emas");
        exit();
    }
}

if ($data == "addchannel") {
    if ($admins) {
        $key = json_encode(['inline_keyboard' => [
            [['text' => $orqa, 'callback_data' => "channels"]],
        ]]);
        edit("Kanal username'sini kiriting:", $key);
        step($data);
        exit();
    }
}

if ($step == "addchannel") {
    if ($admins) {
        if (is_admin($text) == true) {
            if (mb_stripos($kanal, "@") !== false) {
                $put = "$kanal\n$text";
            } else {
                $put = $text;
            }
            $key = json_encode(['inline_keyboard' => [
                [['text' => $orqa, 'callback_data' => "channels"]],
            ]]);
            file_put_contents("admin/kanal.txt", $put);
            send("<b>«".$text."»</b> qo‘shildi", $key);
            step('0');
            exit();
        } else {
            $key = json_encode(['inline_keyboard' => [
                [['text' => "Admin qilish", 'url' => "https://t.me/$bot?startchannel=on&admin=manage_chat+delete_messages+manage_video_chats+restrict_members+promote_members+change_info+invite_users+post_messages+edit_messages+post_stories+pin_messages+edit_stories+delete_stories+manage_topics"]],
                [['text' => $orqa, 'callback_data' => "channels"]],
            ]]);
            send("Bot ushbu kanalda administrator emas! Qayta urining.", $key);
            exit();
        }
    }
}

if ($data == "cheque") {
    if ($admins) {
        delete();
        send("Chek qiymatini kiriting:", $backpanel);
        step($data);
        exit();
    }
}

if ($step == "cheque") {
    if ($admins) {
        $uniqid = uniqid();
        if (is_numeric($text) == true) {
            send("<b>Chek yaratildi!</b>\n
https://t.me/$bot?start=$uniqid", null);
            mysqli_query($connect, "INSERT INTO cheques(cheque,money,status,user) VALUES ('$uniqid','$text','on','unused')");
            step('0');
            exit();
        } else {
            send("❕ Raqamlardan foydalaning", $backpanel);
            exit();
        }
    }
}

// ========== RUCHNOY TO'LOV VA BOT STARS BALANSI ==========
if (isset($pre_checkout_query)) {
    bot('answerPreCheckoutQuery', [
        'pre_checkout_query_id' => $pre_checkout_query->id,
        'ok' => true
    ]);
    exit();
}

if (isset($successful_payment) && $successful_payment) {
    $payload = $successful_payment->invoice_payload ?? '';
    if (mb_stripos($payload, "admin_star_topup=") === 0) {
        $topupId = (int)explode("=", $payload)[1];
        $amount = (int)($successful_payment->total_amount ?? 0);
        $chargeId = sql_escape($successful_payment->telegram_payment_charge_id ?? '');
        mysqli_query($connect, "UPDATE bot_star_topups SET status = 'paid', paid_at = '$sana $time', charge_id = '$chargeId' WHERE id = '$topupId'");
        send("<b>✅ Bot Stars balansi to‘ldirildi!</b>\n\n⭐ Miqdor: <code>$amount Stars</code>\n🧾 To‘lov ID: <code>$topupId</code>", $panel);
        step("0");
        exit();
    }
}

if($data == "admin_stars_topup" && $admins){
    delete();
    send("<b>⭐ Bot balansini nechta Telegram Stars bilan to‘ldirmoqchisiz?</b>\n\nMasalan: <code>100</code>", $backpanel);
    step("admin_stars_topup_amount");
    exit();
}

if($step == "admin_stars_topup_amount" && $admins && isset($text)){
    $amount = (int)str_replace([" ", ","], ["", ""], trim($text));
    if($amount <= 0){
        send("<b>❌ Faqat musbat raqam kiriting.</b>", $backpanel);
        exit();
    }
    $payload = "admin_star_topup=0";
    mysqli_query($connect, "INSERT INTO bot_star_topups(`admin_id`,`amount`,`status`,`payload`,`created_at`) VALUES ('$cid','$amount','pending','','$sana $time')");
    $topupId = mysqli_insert_id($connect);
    $payload = "admin_star_topup=$topupId";
    $payloadEsc = sql_escape($payload);
    mysqli_query($connect, "UPDATE bot_star_topups SET payload = '$payloadEsc' WHERE id = '$topupId'");
    $invoice = bot('sendInvoice', [
        'chat_id' => $cid,
        'title' => "Bot Stars balansini to‘ldirish",
        'description' => "$amount Telegram Stars bot balansiga qo‘shiladi.",
        'payload' => $payload,
        'provider_token' => '',
        'currency' => 'XTR',
        'prices' => json_encode([
            ['label' => 'Telegram Stars', 'amount' => $amount]
        ], JSON_UNESCAPED_UNICODE)
    ]);
    if($invoice && isset($invoice->ok) && $invoice->ok){
        send("<b>👇 To‘lov oynasi yuborildi.</b>\n\nTelegram Stars bilan to‘lovni tasdiqlang.", $backpanel);
    } else {
        $error = $invoice->description ?? "Invoice yuborishda xatolik";
        mysqli_query($connect, "UPDATE bot_star_topups SET status = 'failed' WHERE id = '$topupId'");
        send("<b>❌ Stars to‘lov oynasi yuborilmadi:</b> " . h($error), $backpanel);
    }
    step("0");
    exit();
}

if($data == "manualpay_admin" && $admins){
    $active = mysqli_num_rows(mysqli_query($connect, "SELECT id FROM manual_payment_cards WHERE status = 'active'"));
    $allCards = mysqli_num_rows(mysqli_query($connect, "SELECT id FROM manual_payment_cards WHERE status != 'deleted'"));
    $pending = mysqli_num_rows(mysqli_query($connect, "SELECT id FROM manual_payments WHERE status = 'review'"));
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>"➕ Karta qo‘shish",'callback_data'=>"manual_card_add"],['text'=>"📋 Kartalar",'callback_data'=>"manual_cards_list"]],
        [['text'=>"🧾 Kutilayotgan to‘lovlar ($pending)",'callback_data'=>"manual_payments_pending"]],
        [['text'=>$orqa,'callback_data'=>"panel"]]
    ]], JSON_UNESCAPED_UNICODE);
    edit("<b>💳 Ruchnoy to‘lov tizimi</b>\n\nFaol kartalar: <code>$active ta</code>\nJami kartalar: <code>$allCards ta</code>\nTekshiruvdagi to‘lovlar: <code>$pending ta</code>", $key);
    step("0");
    exit();
}

if($data == "manual_card_add" && $admins){
    delete();
    send("<b>💳 Karta raqamini kiriting:</b>\n\nMasalan: <code>8600 0000 0000 0000</code>", json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"manualpay_admin"]]
    ]], JSON_UNESCAPED_UNICODE));
    step("manual_card_number");
    exit();
}

if($step == "manual_card_number" && $admins && isset($text)){
    $cardNumber = trim($text);
    $digits = preg_replace('/\D+/', '', $cardNumber);
    if(strlen($digits) < 12 || strlen($digits) > 25){
        send("<b>❌ Karta raqami noto‘g‘ri.</b>\n\nQayta kiriting:", $backpanel);
        exit();
    }
    save_temp_json('manual_card', $cid, ['card_number' => $cardNumber]);
    send("<b>👤 Karta egasining ism-familiyasini kiriting:</b>", json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"manualpay_admin"]]
    ]], JSON_UNESCAPED_UNICODE));
    step("manual_card_owner");
    exit();
}

if($step == "manual_card_owner" && $admins && isset($text)){
    $temp = load_temp_json('manual_card', $cid);
    $owner = trim($text);
    if($owner === ''){
        send("<b>❌ Karta egasi bo‘sh bo‘lmasin.</b>", $backpanel);
        exit();
    }
    $temp['owner'] = $owner;
    save_temp_json('manual_card', $cid, $temp);
    send("<b>📝 To‘lov uchun izoh kiriting:</b>\n\nMasalan: <code>Chekni yuborgach admin tasdiqlaydi</code>", json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"manualpay_admin"]]
    ]], JSON_UNESCAPED_UNICODE));
    step("manual_card_note");
    exit();
}

if($step == "manual_card_note" && $admins && isset($text)){
    $temp = load_temp_json('manual_card', $cid);
    $cardNumber = sql_escape($temp['card_number'] ?? '');
    $owner = sql_escape($temp['owner'] ?? '');
    $note = sql_escape(trim($text));
    if($cardNumber === '' || $owner === ''){
        send("<b>❌ Ma'lumotlar topilmadi. Qaytadan karta qo‘shing.</b>", $backpanel);
        step("0");
        clear_temp_json('manual_card', $cid);
        exit();
    }
    mysqli_query($connect, "INSERT INTO manual_payment_cards(`card_number`,`owner`,`note`,`status`,`created_at`) VALUES ('$cardNumber','$owner','$note','active','$sana $time')");
    clear_temp_json('manual_card', $cid);
    send("<b>✅ To‘lov kartasi qo‘shildi!</b>\n\n💳 Karta: <code>" . h($temp['card_number']) . "</code>\n👤 Egasi: " . h($temp['owner']) . "\n📝 Izoh: " . h($text), $backpanel);
    step("0");
    exit();
}

if($data == "manual_cards_list" && $admins){
    $result = mysqli_query($connect, "SELECT * FROM manual_payment_cards WHERE status != 'deleted' ORDER BY id DESC LIMIT 20");
    $textCards = "<b>📋 To‘lov kartalari:</b>\n\n";
    $keyboard = [];
    while($card = mysqli_fetch_assoc($result)){
        $status = $card['status'] == 'active' ? '✅ Faol' : '⏸ O‘chiq';
        $textCards .= "<b>#{$card['id']}</b> $status\n💳 <code>" . h($card['card_number']) . "</code>\n👤 " . h($card['owner']) . "\n\n";
        $toggleText = $card['status'] == 'active' ? "⏸ #{$card['id']}" : "✅ #{$card['id']}";
        $keyboard[] = [
            ['text'=>$toggleText, 'callback_data'=>"manual_card_toggle={$card['id']}"],
            ['text'=>"🗑 #{$card['id']}", 'callback_data'=>"manual_card_del={$card['id']}"]
        ];
    }
    if(empty($keyboard)){
        $textCards .= "Hali karta qo‘shilmagan.";
    }
    $keyboard[] = [['text'=>"➕ Karta qo‘shish",'callback_data'=>"manual_card_add"]];
    $keyboard[] = [['text'=>$orqa,'callback_data'=>"manualpay_admin"]];
    edit($textCards, json_encode(['inline_keyboard'=>$keyboard], JSON_UNESCAPED_UNICODE));
    exit();
}

if(mb_stripos($data, "manual_card_toggle=") !== false && $admins){
    $id = (int)explode("=", $data)[1];
    $card = get_manual_card($id);
    if(!$card){ ans("Karta topilmadi"); exit(); }
    $newStatus = $card['status'] == 'active' ? 'disabled' : 'active';
    mysqli_query($connect, "UPDATE manual_payment_cards SET status = '$newStatus' WHERE id = '$id'");
    ans("Karta holati o‘zgartirildi");
    exit();
}

if(mb_stripos($data, "manual_card_del=") !== false && $admins){
    $id = (int)explode("=", $data)[1];
    mysqli_query($connect, "UPDATE manual_payment_cards SET status = 'deleted' WHERE id = '$id'");
    ans("Karta o‘chirildi");
    exit();
}

if($data == "manual_payments_pending" && $admins){
    $result = mysqli_query($connect, "SELECT * FROM manual_payments WHERE status = 'review' ORDER BY id DESC LIMIT 30");
    $keyboard = [];
    $body = "<b>🧾 Kutilayotgan ruchnoy to‘lovlar:</b>\n\n";
    while($payment = mysqli_fetch_assoc($result)){
        $body .= "#{$payment['id']} - <a href='tg://user?id={$payment['user_id']}'>{$payment['user_id']}</a> - " . money_fmt($payment['amount']) . " so‘m\n";
        $keyboard[] = [['text'=>"🧾 #{$payment['id']} - " . money_fmt($payment['amount']) . " so‘m", 'callback_data'=>"manual_view={$payment['id']}"]];
    }
    if(empty($keyboard)){
        $body .= "Tekshiruvdagi to‘lov yo‘q.";
    }
    $keyboard[] = [['text'=>$orqa,'callback_data'=>"manualpay_admin"]];
    edit($body, json_encode(['inline_keyboard'=>$keyboard], JSON_UNESCAPED_UNICODE));
    exit();
}

if(mb_stripos($data, "manual_view=") !== false && $admins){
    $id = (int)explode("=", $data)[1];
    $payment = get_manual_payment($id);
    if(!$payment){ ans("To‘lov topilmadi"); exit(); }
    $card = get_manual_card($payment['card_id']);
    $key = json_encode(['inline_keyboard'=>[
        [
            ['text'=>"✅ Tasdiqlash",'callback_data'=>"manual_approve=$id"],
            ['text'=>"❌ Rad etish",'callback_data'=>"manual_reject=$id"]
        ],
        [['text'=>"📎 Chekni qayta yuborish",'callback_data'=>"manual_copy=$id"]],
        [['text'=>$orqa,'callback_data'=>"manual_payments_pending"]]
    ]], JSON_UNESCAPED_UNICODE);
    edit(manual_payment_admin_text($payment, $card, "🧾 Ruchnoy to‘lov"), $key);
    exit();
}

if(mb_stripos($data, "manual_copy=") !== false && $admins){
    $id = (int)explode("=", $data)[1];
    $payment = get_manual_payment($id);
    if(!$payment){ ans("To‘lov topilmadi"); exit(); }
    bot('copyMessage', [
        'chat_id' => $cid,
        'from_chat_id' => $payment['proof_chat_id'],
        'message_id' => $payment['proof_message_id']
    ]);
    ans("Chek yuborildi");
    exit();
}

if(mb_stripos($data, "manual_approve=") !== false && $admins){
    $id = (int)explode("=", $data)[1];
    if(!order_lock('manual_payment', $id)){ ans("Bu to‘lov qayta ishlanmoqda"); exit(); }
    $payment = get_manual_payment($id);
    if(!$payment || $payment['status'] !== 'review'){
        order_unlock('manual_payment', $id);
        ans("To‘lov allaqachon ko‘rib chiqilgan");
        exit();
    }
    $amount = (int)$payment['amount'];
    mysqli_query($connect, "UPDATE users SET money = money + $amount WHERE user_id = '{$payment['user_id']}'");
    mysqli_query($connect, "UPDATE manual_payments SET status = 'approved', admin_id = '$cid', checked_at = '$sana $time' WHERE id = '$id'");
    $updated = get_manual_payment($id);
    update_manual_admin_messages($updated, "✅ Ruchnoy to‘lov tasdiqlandi");
    bot('sendMessage', [
        'chat_id' => $payment['user_id'],
        'text' => "<b>✅ To‘lovingiz tasdiqlandi!</b>\n\n💳 Hisobingizga <code>" . money_fmt($amount) . " so‘m</code> qo‘shildi.",
        'parse_mode' => 'html'
    ]);
    order_unlock('manual_payment', $id);
    ans("Tasdiqlandi");
    exit();
}

if(mb_stripos($data, "manual_reject=") !== false && $admins){
    $id = (int)explode("=", $data)[1];
    if(!order_lock('manual_payment', $id)){ ans("Bu to‘lov qayta ishlanmoqda"); exit(); }
    $payment = get_manual_payment($id);
    if(!$payment || $payment['status'] !== 'review'){
        order_unlock('manual_payment', $id);
        ans("To‘lov allaqachon ko‘rib chiqilgan");
        exit();
    }
    mysqli_query($connect, "UPDATE manual_payments SET status = 'rejected', admin_id = '$cid', checked_at = '$sana $time' WHERE id = '$id'");
    $updated = get_manual_payment($id);
    update_manual_admin_messages($updated, "❌ Ruchnoy to‘lov rad etildi");
    bot('sendMessage', [
        'chat_id' => $payment['user_id'],
        'text' => "<b>❌ To‘lovingiz rad etildi.</b>\n\nAgar xatolik bo‘lsa, qayta chek yuboring yoki admin bilan bog‘laning.",
        'parse_mode' => 'html'
    ]);
    order_unlock('manual_payment', $id);
    ans("Rad etildi");
    exit();
}

if($data == "manual_pay" && joinchat($cid) == true){
    $card = get_active_manual_card();
    if(!$card){
        edit("<b>❌ Hozircha ruchnoy to‘lov kartasi sozlanmagan.</b>\n\nIltimos, keyinroq urinib ko‘ring.", json_encode(['inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"start"]]
        ]], JSON_UNESCAPED_UNICODE));
        exit();
    }
    edit("<b>💳 Balansingizni necha so‘mga to‘ldirmoqchisiz?</b>\n\nMinimal miqdor: <code>1 000 so‘m</code>", json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"start"]]
    ]], JSON_UNESCAPED_UNICODE));
    step("manual_pay_amount");
    exit();
}

if($step == "manual_pay_amount" && isset($text)){
    $amount = (int)str_replace([" ", ","], ["", ""], trim($text));
    if($amount < 1000){
        send("<b>❌ Minimal to‘lov miqdori 1 000 so‘m.</b>\n\nQayta summa kiriting:", json_encode(['inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"start"]]
        ]], JSON_UNESCAPED_UNICODE));
        exit();
    }
    $card = get_active_manual_card();
    if(!$card){
        send("<b>❌ Hozircha ruchnoy to‘lov kartasi sozlanmagan.</b>", $menu);
        step("0");
        exit();
    }
    mysqli_query($connect, "INSERT INTO manual_payments(`user_id`,`card_id`,`amount`,`status`,`created_at`) VALUES ('$cid','{$card['id']}','$amount','pending','$sana $time')");
    $paymentId = mysqli_insert_id($connect);
    $note = trim((string)$card['note']);
    $noteText = $note !== '' ? "\n📝 <b>Izoh:</b> " . h($note) : '';
    send("<b>💳 Ruchnoy to‘lov</b>\n\n💰 <b>Summa:</b> <code>" . money_fmt($amount) . " so‘m</code>\n💳 <b>Karta:</b> <code>" . h($card['card_number']) . "</code>\n👤 <b>Karta egasi:</b> " . h($card['owner']) . "$noteText\n\nTo‘lov qilgach, pastdagi tugmani bosing.", json_encode(['inline_keyboard'=>[
        [['text'=>"✅ To‘lov qildim",'callback_data'=>"manual_paid=$paymentId"]],
        [['text'=>$orqa,'callback_data'=>"start"]]
    ]], JSON_UNESCAPED_UNICODE));
    step("0");
    exit();
}

if(mb_stripos($data, "manual_paid=") !== false){
    $id = (int)explode("=", $data)[1];
    $payment = get_manual_payment($id);
    if(!$payment || $payment['user_id'] != $cid || $payment['status'] !== 'pending'){
        ans("To‘lov topilmadi yoki allaqachon yuborilgan");
        exit();
    }
    edit("<b>🧾 To‘lov chekini yuboring.</b>\n\nRasm, skrinshot, fayl yoki hujjat formatida yuborishingiz mumkin.", json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"start"]]
    ]], JSON_UNESCAPED_UNICODE));
    step("manual_receipt=$id");
    exit();
}

if(mb_stripos($step, "manual_receipt=") !== false && isset($message)){
    $id = (int)explode("=", $step)[1];
    $payment = get_manual_payment($id);
    if(!$payment || $payment['user_id'] != $cid || $payment['status'] !== 'pending'){
        send("<b>❌ To‘lov topilmadi yoki allaqachon yuborilgan.</b>", $menu);
        step("0");
        exit();
    }
    mysqli_query($connect, "UPDATE manual_payments SET status = 'review', proof_chat_id = '$cid', proof_message_id = '$mid' WHERE id = '$id'");
    send_manual_payment_to_admins($id);
    send("<b>✅ Chekingiz adminga yuborildi!</b>\n\nTo‘lov tasdiqlansa balansingiz avtomatik to‘ldiriladi.", $menu);
    step("0");
    exit();
}
// ========== RUCHNOY TO'LOV VA BOT STARS BALANSI TUGADI ==========

// ========== FRAGMENT API SOZLAMALARI (ADMIN PANEL) ==========
if($data == "starapi" && $admins){
    $apiKey = trim(file_get_contents("set/fragment_api_key.txt"));
    $apiKey_display = $apiKey ? hide($apiKey) : "❌ Kiritilmagan";
    
    $key = json_encode([
        'inline_keyboard'=>[
            [['text'=>"🔑 API Kalit",'callback_data'=>"frag_api_key"]],
            [['text'=>"⭐ Stars narxi",'callback_data'=>"staredit=50"]],
            [['text'=>"🧪 To‘liq API test",'callback_data'=>"test_fragment_api"]],
            [['text'=>$orqa,'callback_data'=>"panel"]]
        ]
    ]);
    
    $balanceText = "";
    if($apiKey){
        $fragment = new FragmentUzAPI($apiKey);
        $balance = $fragment->getWalletBalance();
        if($balance){
            $balanceText = "\n\n💰 Balans: " . ($balance['balance_ton'] ?? '0') . " TON";
        }
    }
    $botStars = get_bot_star_balance_amount();
    if($botStars !== null){
        $balanceText .= "\n⭐ Bot Stars balansi: $botStars Stars";
    }
    
    edit("<b>🔐 Fragment API Sozlamalari</b>\n\n🔑 API Kalit: <code>$apiKey_display</code>$balanceText\n\nO'zgartirish uchun tugmalarni bosing:", $key);
    exit();
}

if($data == "frag_api_key" && $admins){
    step("frag_api_key");
    delete();
    send("<b>🔑 Fragment API kalitini kiriting:</b>\n\nAPI kalitni fragment-api.uz saytidan olishingiz mumkin.", $backpanel);
    exit();
}

if($step == "frag_api_key" && $admins){
    file_put_contents("set/fragment_api_key.txt", trim($text));
    send("<b>✅ API kalit saqlandi!</b>", $backpanel);
    step("0");
    exit();
}

if($data == "test_fragment_api" && $admins){
    $apiKey = trim(file_get_contents("set/fragment_api_key.txt"));
    
    if(empty($apiKey)){
        send("<b>❌ API kalit kiritilmagan!</b>\n\nIltimos, avval API kalitni kiriting.", $backpanel);
        exit();
    }
    
    $fragment = new FragmentUzAPI($apiKey);
    $balance = $fragment->getWalletBalance();
    if(!$balance){
        send("<b>❌ Fragment API ulanmagan:</b> " . h($fragment->getLastError()) . "\n\nAPI kalitni tekshiring yoki loyiha hamyoni sozlanganiga ishonch hosil qiling.", $backpanel);
        exit();
    }

    $starsPricing = $fragment->getStarsPricing(60);
    $starsPricingText = $starsPricing
        ? "✅ 60 Stars narxi: <code>" . h($starsPricing['price']['ton'] ?? '-') . " TON</code>"
        : "❌ Stars pricing: " . h($fragment->getLastError());

    $premiumPricing = $fragment->getPremiumPricing();
    $premiumText = "❌ Premium pricing: " . h($fragment->getLastError());
    if($premiumPricing && !empty($premiumPricing['packages'])){
        $rows = [];
        foreach($premiumPricing['packages'] as $pkg){
            $rows[] = h($pkg['months'] ?? '-') . " oy: " . h($pkg['ton'] ?? '-') . " TON";
        }
        $premiumText = "✅ Premium paketlari: <code>" . implode(" | ", $rows) . "</code>";
    }

    $calc = $fragment->walletCalculate();
    $calcText = $calc
        ? "✅ Hamyon imkoniyati: max <code>" . h($calc['stars']['max_amount'] ?? '0') . " Stars</code>"
        : "⚠️ Hamyon calculate: " . h($fragment->getLastError());

    $botStars = get_bot_star_balance_amount();
    $botStarsText = $botStars !== null ? "\n⭐ Bot Stars balansi: <code>$botStars Stars</code>" : "";

    send("<b>✅ Fragment API to‘liq testdan o‘tdi</b>\n\n💰 Balans: <code>" . h($balance['balance_ton'] ?? '0') . " TON</code>\n🏦 Hamyon: <code>" . h(substr(($balance['address'] ?? ''), 0, 12)) . "...</code>\n$starsPricingText\n$premiumText\n$calcText$botStarsText\n\n<b>Eslatma:</b> bu test real xarid qilmaydi, pul yechmaydi.", $backpanel);
    exit();
}

if(mb_stripos($data,"staredit=")!==false){
    $tx = explode("=",$data)[1];
    step($data);
    delete();
    if($tx == "50"){
        send("<b>⭐ Yangi stars narxini kiriting (1 dona uchun):</b>\n\nMasalan: 220", $backpanel);
    }
    exit();
}

if(mb_stripos($step,"staredit=")!==false){
    $tx = explode("=",$step)[1];
    if($tx == "50"){
        if(is_numeric($text)){
            file_put_contents("set/50.txt", $text);
            send("<b>✅ Stars narxi o'zgartirildi!</b>", $backpanel);
        } else {
            send("<b>❌ Faqat raqam kiriting!</b>", $backpanel);
        }
    }
    step("0");
    exit();
}

// ========== NOMER API SOZLAMALARI (ADMIN PANEL) ==========
if($data == "raqamapi" && $admins){
    $simkey = @file_get_contents("set/raqam_api_key.txt");
    $simfoiz = @file_get_contents("set/raqam_foiz.txt") ?: "20";
    $nomer_kanal = @file_get_contents("nomer_ch.txt");
    $jamiraqam = @file_get_contents("tizim/jamiraqam.txt") ?: "0";

    $api_display = $simkey ? hide($simkey) : "❌ Kiritilmagan";

    $key = json_encode([
        'inline_keyboard'=>[
            [['text'=>"🔑 API Kalit",'callback_data'=>"raqam_api_key"]],
            [['text'=>"📊 Foiz (+%)",'callback_data'=>"raqam_foiz_edit"]],
            [['text'=>"📢 Kanal",'callback_data'=>"raqam_kanal_edit"]],
            [['text'=>"📋 Statistika",'callback_data'=>"raqam_stat"]],
            [['text'=>$orqa,'callback_data'=>"panel"]]
        ]
    ]);

    edit("<b>📞 Nomera olish sozlamalari</b>\n\n🔑 API Kalit: <code>$api_display</code>\n📊 Foiz: <code>$simfoiz%</code>\n📢 Kanal: " . ($nomer_kanal ? "<code>$nomer_kanal</code>" : "❌ Kiritilmagan") . "\n📋 Jami sotilgan: <code>$jamiraqam ta</code>\n\nO'zgartirish uchun tugmalarni bosing:", $key);
    exit();
}

if($data == "raqam_api_key" && $admins){
    step("raqam_api_key");
    delete();
    send("<b>🔑 Nomera olish API kalitini kiriting:</b>\n\nAPI kalitni pixsim.uz saytidan olishingiz mumkin.", $backpanel);
    exit();
}

if($step == "raqam_api_key" && $admins){
    file_put_contents("set/raqam_api_key.txt", trim($text));
    send("<b>✅ API kalit saqlandi!</b>", $backpanel);
    step("0");
    exit();
}

if($data == "raqam_foiz_edit" && $admins){
    step("raqam_foiz");
    delete();
    $current = @file_get_contents("set/raqam_foiz.txt") ?: "20";
    send("<b>📊 Qaysi foiz qo'shmoqchisiz?</b>\n\nHozirgi: <code>$current%</code>\n\nMasalan: 20 (bu 20% qo'shadi)", $backpanel);
    exit();
}

if($step == "raqam_foiz" && $admins){
    if(is_numeric($text) && $text >= 0 && $text <= 100){
        file_put_contents("set/raqam_foiz.txt", $text);
        send("<b>✅ Foiz yangilandi: $text%</b>", $backpanel);
    } else {
        send("<b>❌ Faqat 0-100 oralig'ida raqam kiriting!</b>", $backpanel);
    }
    step("0");
    exit();
}

if($data == "raqam_kanal_edit" && $admins){
    step("raqam_kanal");
    delete();
    $current = @file_get_contents("nomer_ch.txt") ?: "Kiritilmagan";
    send("<b>📢 Nomera olish haqida xabar yuborish uchun kanal ID yoki username:</b>\n\nHozirgi: <code>$current</code>\n\nMasalan: -100123456789 yoki @channel_nomi\nBo'sh qoldirish uchun 'yoq' deb yozing.", $backpanel);
    exit();
}

if($step == "raqam_kanal" && $admins){
    if($text == "yoq"){
        file_put_contents("nomer_ch.txt", "");
        send("<b>✅ Kanal olib tashlandi!</b>", $backpanel);
    } else {
        file_put_contents("nomer_ch.txt", $text);
        send("<b>✅ Kanal saqlandi: $text</b>", $backpanel);
    }
    step("0");
    exit();
}

if($data == "raqam_stat" && $admins){
    $jamiraqam = @file_get_contents("tizim/jamiraqam.txt") ?: "0";
    $simkey = @file_get_contents("set/raqam_api_key.txt");

    $stat_text = "<b>📋 Nomera olish statistikasi</b>\n\n";
    $stat_text .= "📊 Jami sotilgan raqamlar: <code>$jamiraqam ta</code>\n";
    $stat_text .= "🔑 API Kalit: " . ($simkey ? "✅ Uланган" : "❌ Kiritilmagan") . "\n";

    if($simkey){
        $api_response = json_decode(file_get_contents("https://pixsim.uz/api?key=$simkey&action=getBalance"), true);
        if($api_response['ok']){
            $balance = $api_response['result']['balance'] ?? 0;
            $stat_text .= "💰 API Balans: <code>$balance so'm</code>";
        }
    }

    bot('editMessageText', [
        'chat_id' => $cid,
        'message_id' => $mid,
        'text' => $stat_text,
        'parse_mode' => 'html',
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "🔄 Yangilash", 'callback_data' => "raqam_stat"]],
                [['text' => $orqa, 'callback_data' => "raqamapi"]]
            ]
        ])
    ]);
    exit();
}



if($data == 'sendusers'){
    if($admin){
        $result = mysqli_query($connect, "SELECT * FROM send");
        $row = mysqli_fetch_assoc($result);
        if(!$row){
            edit("<b><tg-emoji emoji-id=\"5444856076954520455\">👋</tg-emoji> Foydalanuvchilarga yuboriladigan xabarni botga yuboring!</b>",$backpanel);
            step("send");
            exit();
        }else{
            $a = mysqli_query($connect,"SELECT*FROM send");
            $b = mysqli_fetch_assoc($a);
            $c = $b['start_id'];
            $limit = "150";
            $azo = mysqli_num_rows(mysqli_query($connect,"SELECT*FROM users"));
            $q = floor(($azo - $c)/$limit) + 1;
            $key = json_encode(['inline_keyboard'=>[
                [['text'=>"Xabar yuborishni to‘xtatish",'callback_data'=>"stopsend"]],
            ]]);
            send("<b>📑 Xabar yuborish jarayoni davom etmoqda.\n
XABAR HOLATI:</b>\n<blockquote>Yuborildi : $c ta
Qolgan vaqt : $q minut</blockquote>\n
<i>Xabar yuborishni to'xtatish uchun pastdagi tugmani bosing</i> 👇",$key);
            exit();
        }
    }
}

if($data == "stopsend"){
    step("0");
    ans("Xabar yuborish tugatildi");
    edit("<b>Xabar yuborish tugatildi!</b>",null);
    mysqli_query($connect,"DELETE FROM send");
    exit();
}

if($step == "send" and isset($admins)){
    $result = mysqli_query($connect, "SELECT * FROM users");
    $stat = mysqli_num_rows($result);
    $res = mysqli_query($connect,"SELECT * FROM users WHERE id = '$stat'");
    $row = mysqli_fetch_assoc($res);
    $user_id = $row['user_id'];
    $time1 = date('H:i', strtotime('+1 minutes'));
    $time2 = date('H:i', strtotime('+2 minutes'));
    $tugma = json_encode($update->message->reply_markup);
    $reply_markup = base64_encode($tugma);
    mysqli_query($connect, "INSERT INTO send (`time1`,`time2`,`start_id`,`stop_id`,`admin_id`,`message_id`,`reply_markup`,`step`) VALUES ('$time1','$time2','0','$user_id','$cid','$mid','$reply_markup','send')");
    send("<b>📑 Xabar foydalanuvchilarga $time1 da yuborish boshlanadi!</b>",$backpanel);
    step('0');
    exit();
}

$result = mysqli_query($connect, "SELECT * FROM send"); 
$row = mysqli_fetch_assoc($result);
$sendstep = $row['step'];

if($_GET['update']=="send"){
    $row1 = $row['time1'];
    $row2 = $row['time2'];
    $row3 = $row['time3'];
    $row4 = $row['time4'];
    $row5 = $row['time5'];
    $start_id = $row['start_id'];
    $stop_id = $row['stop_id'];
    $admin_id = $row['admin_id'];
    $mied = $row['message_id'];
    $tugma = $row['reply_markup'];
    if($tugma == "bnVsbA=="){
        $reply_markup = "";
    }else{
        $reply_markup = base64_decode($tugma);
    }
    $time1 = date('H:i', strtotime('+1 minutes'));
    $time2 = date('H:i', strtotime('+2 minutes'));
    $time3 = date('H:i', strtotime('+3 minutes'));
    $time4 = date('H:i', strtotime('+4 minutes'));
    $time5 = date('H:i', strtotime('+5 minutes'));
    $limit = 150;

    if($time == $row1 or $time == $row2 or $time == $row3 or $time == $row4 or $time == $row5){
        $sql = "SELECT * FROM users LIMIT $start_id,$limit";
        $res = mysqli_query($connect,$sql);
        while($a = mysqli_fetch_assoc($res)){
            $id = $a['user_id'];
            if($id == $stop_id){
                bot('ForwardMessage',[
                    'chat_id'=>$id,
                    'from_chat_id'=>$admin_id,
                    'message_id'=>$mied
                ]);
                bot('sendMessage',[
                    'chat_id'=>$admin_id,
                    'text'=>"<b>✅ Xabar barcha bot foydalanuvchilariga yuborildi!</b>",
                    'parse_mode'=>'html'
                ]);
                mysqli_query($connect, "DELETE FROM send");
                exit;
            }else{
                bot('ForwardMessage',[
                    'chat_id'=>$id,
                    'from_chat_id'=>$admin_id,
                    'message_id'=>$mied
                ]);
            }
        }
        mysqli_query($connect, "UPDATE send SET time1 = '$time1'");
        mysqli_query($connect, "UPDATE send SET time2 = '$time2'");
        mysqli_query($connect, "UPDATE send SET time3 = '$time3'");
        mysqli_query($connect, "UPDATE send SET time4 = '$time4'");
        mysqli_query($connect, "UPDATE send SET time5 = '$time5'");
        $get_id = $start_id + $limit;
        mysqli_query($connect, "UPDATE send SET start_id = '$get_id'");
        bot('sendMessage',[
            'chat_id'=>$admin_id,
            'text'=>"<b>✅ Yuborildi: $get_id</b>",
            'parse_mode'=>'html'
        ]);
    }
    echo json_encode(["status"=>true,"cron"=>"Sending message"]);
}

if($data == "setkonkurs"){
    if($admins){
        if($konkurs == "off"){
            $txt = "❌ <b>Referal konkurs mavjud emas!</b>\n
Referal konkurs boshlamoqchi bo‘lsangiz pastdagi tugmadan foydalaning.";
            $kei = "🚀 Konkurs boshlash";
            $key = json_encode(['inline_keyboard'=>[
                [['text'=>$kei,'callback_data'=>"startgo"]],
                [['text'=>$orqa, 'callback_data'=>"panel"]]
            ]]);
        }else{
            $txt = "✅ <b>Referal konkurs mavjud!\n
Tugash vaqti:</b> $konkurs
<b>Konkurs holati:</b> davom etmoqda";
            $kei = "❌ Konkursni yakunlash";
            $key = json_encode(['inline_keyboard'=>[
                [['text'=>"📝 Ma'lumotlarni o'zgartirish",'callback_data'=>"startgo"]],
                [['text'=>$kei,'callback_data'=>"stopgo"]],
                [['text'=>$orqa, 'callback_data'=>"panel"]]
            ]]);
        }
        edit($txt,$key);
        step("0");
        exit();
    }
}

if($data == "startgo"){
    if($admins){
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"setkonkurs"]],
        ]]);
        $days1 = date("d.m.Y",strtotime('+1 days'));
        $days3 = date("d.m.Y",strtotime('+3 days'));
        $days7 = date("d.m.Y",strtotime('+7 days'));
        $days10 = date("d.m.Y",strtotime('+10 days'));
        $days15 = date("d.m.Y",strtotime('+15 days'));
        $days30 = date("d.m.Y",strtotime('+30 days'));
        edit("⏳ <b>Konkursni qachon yakunlamoqchisiz?\n
• 1 kunda: <code>$days1 $time</code>
• 3 kunda: <code>$days3 $time</code>
• 7 kunda: <code>$days7 $time</code>
• 10 kunda: <code>$days10 $time</code>
• 15 kunda: <code>$days15 $time</code>
• 30 kunda:</b> <code>$days30 $time</code>\n
O'zingiz hohlagan sana va vaqtni kiriting:",$key);
        step($data);
        exit();
    }
}

if($step == "startgo"){
    file_put_contents("set/konkurs.txt",$text);
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"setkonkurs"]],
    ]]);
    send("🗒️ <b>Konkurs uchun info kiriting:</b>\n
Belgilash tili HTML",$key);
    step("startgo2");
    exit();
}

if($step == "startgo2"){
    step("0");
    file_put_contents("set/konkurs.info",$text);
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"setkonkurs"]],
    ]]);
    send("✅ <b>Konkurs muvaffaqiyatli yaratildi!</b>",$key);
    exit();
}

if($data == "stopgo"){
    if($admins){
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"❌ Konkursni tugatish",'callback_data'=>"stopgo2"]],
            [['text'=>$orqa,'callback_data'=>"setkonkurs"]],
        ]]);
        edit("‼️ <b>Konkursni tugatmoqchimisiz?</b>",$key);
        exit();
    }
}

if($data == "stopgo2"){
    delete();
    $kuz = referalid(10);
    send("✅ <b>Referal konkurs yakunlandi</b>\n
$kuz",null);
    send("👇",$backpanel);
    file_put_contents("set/konkurs.txt","off");
    unlink("set/konkurs.info");
    deldir("ref");
    step("0");
    exit();
}

if($_GET['update']=="konkurs"){
    echo json_encode(['cron'=>"working"]);
    $ksana = explode(" ",$konkurs)[0];
    $ksoat = explode(" ",$konkurs)[1];
    if($ksana == $sana and $ksoat == $time){
        $results = referalid(10);
        bot('sendMessage',['chat_id'=>$admincha,
            'text'=>"✅ <b>Referal konkurs yakunlandi!</b>\n
$results",
            'parse_mode'=>'html'
        ]);
        unlink("set/konkurs.info");
        unlink("set/konkurs.txt");
        exit();
    }
}

if ($text == "/droptable" and $cid == $devid) {
    mysqli_query($connect, "DROP TABLE bots");
    deldir("bots");
    send("<b>Tables was being dropped!</b>", null);
    exit();
}

if($data == "raqamapi"){
    if($admins){
        if($apikay){
            $url = "https://api.spider-service.com?apiKay=$apikay&action=getBalance";
            $data = json_decode(file_get_contents($url),true);
            $ok = $data['ok'];
            $error = $data['error'];
            $msg = $data['msg'];
            $wallet = $data['result']['wallet'];
            $currency = $data['result']['currency'];
            $email = $data['result']['email'];
            if($ok == true){
                $key = json_encode(['inline_keyboard'=>[
                    [['text'=>"♻️ Kalitni yangilash",'callback_data'=>"apikay"]],
                    [['text'=>$orqa,'callback_data'=>"panel"]]
                ]]);
                $matn = "🗒️ <b>Raqam API Sozlamalari\n
🔑 API Key: <code>".hide($apikay)."</code>
💰 Balans:</b> $wallet $currency\n
☝️ <b>API kalitingizni hech kimga bermang!</b>";
                edit($matn,$key);
                step("0");
                exit();
            }else{
                $key = json_encode(['inline_keyboard'=>[
                    [['text'=>"♻️ Kalitni yangilash",'callback_data'=>"apikay"]],
                    [['text'=>$orqa,'callback_data'=>"panel"]]
                ]]);
                $matn = "🗒️ <b>Raqam API Sozlamalari\n
🔑 API Key: <code>".hide($apikay)."</code>
💰 Balans:</b> Mavjud emas\n
☝️ <b>API kalit yaroqsiz! Iltimos uni yangilang.</b>";
                edit($matn,$key);
                step("0");
                exit();
            }
        }else{
            $key = json_encode(['inline_keyboard'=>[
                [['text'=>"️✅ Kalitni kiritish",'callback_data'=>"apikay"]],
                [['text'=>$orqa,'callback_data'=>"panel"]]
            ]]);
            $matn = "🗒️ <b>Raqam API Sozlamalari\n
🔑 API Key: Kiritilmagan
💰 Balans:</b> Mavjud emas\n
☝️ <b>API kalit kiritilmagan. Iltimos, quyidagi tugma orqali API ulang!</b>";
            edit($matn,$key);
            step("0");
            exit();
        }
    }
}

if($data == "apikay" and $admins){
    delete();
    send("🔑 <b>@S_PIDERBot</b> dan olingan <b>API Kalit</b>ni kiriting:",$backpanel);
    step($data);
    exit();
}




if($data == "adminid"){
    if($cid == $devid){
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"✏️ ID",'callback_data'=>"admin-id"],['text'=>"✏️ Username",'callback_data'=>"admin-user"]],
            [['text'=>$orqa,'callback_data'=>"panel"]]
        ]]);
        $ad = mysqli_query($connect,"SELECT*FROM admins");
        $adm = mysqli_num_rows($ad);
        edit("🆔 <b>Admin ID:</b> $admin
✏️ <b>Username:</b> @$adminuser\n
👨‍💻 <b>Botdagi adminlar:</b> $adm",$key);
        step('0');
        exit();
    }
}

if($data == "admin-id"){
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"adminid"]]
    ]]);
    edit("🆔 <b>Yangi admin ID kiriting:</b>\n
<blockquote>Masalan: $devid</blockquote>",$key);
    step($data);
    exit();
}

if($step == "admin-id"){
    bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid - 1]);
    delete();
    if(is_numeric($text)==true){
        put("set/admin.txt",$text);
        $admin = $text;
        $admin_lk_url = "tg://user?id=" . trim((string)$admin);
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"✏️ ID",'callback_data'=>"admin-id"],['text'=>"✏️ Username",'callback_data'=>"admin-user"]],
            [['text'=>$orqa,'callback_data'=>"panel"]]
        ]]);
        $ad = mysqli_query($connect,"SELECT*FROM admins");
        $adm = mysqli_num_rows($ad);
        send("🆔 <b>Admin ID:</b> $admin
✏️ <b>Username:</b> @$adminuser\n
👨‍💻 <b>Adminlar soni</b> $adm",$key);
        step('0');
        exit();
    }else{
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>$orqa,'callback_data'=>"adminid"]]
        ]]);
        send("🆔 <b>Yangi admin ID kiriting:</b>\n
<blockquote>Masalan: $devid</blockquote>",$key);
        step($data);
        exit();
    }
}

if($data == "admin-user"){
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"adminid"]]
    ]]);
    edit("🆔 <b>Yangi admin username kiriting:</b>\n
<blockquote>Masalan: @jony_soft</blockquote>",$key);
    step($data);
    exit();
}

if($step == "admin-user"){
    bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid - 1]);
    delete();
    $text = str_replace("@",null,$text);
    put("set/user.txt",$text);
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>"✏️ ID",'callback_data'=>"admin-id"],['text'=>"✏️ Username",'callback_data'=>"admin-user"]],
        [['text'=>$orqa,'callback_data'=>"panel"]]
    ]]);
    $ad = mysqli_query($connect,"SELECT*FROM admins");
    $adm = mysqli_num_rows($ad);
    send("🆔 <b>Admin ID:</b> $admin
✏️ <b>Username:</b> @$text\n
👨‍💻 <b>Adminlar soni:</b> $adm",$key);
    step('0');
    exit();
}



if($text == "/devpanel"){
    if($cid == $umidjon){
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"📆 To‘lov / server sanasi",'callback_data'=>"paytime"]],
        ]]);
        send("⚙️ <b>Developer panel | Dasturchi paneli:</b>",$key);
        step('0');
        exit();
    }
}

if($data == "devpanel"){
    if($cid == $umidjon){
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"📆 To‘lov / server sanasi",'callback_data'=>"paytime"]],
        ]]);
        edit("⚙️ <b>Dasturchi paneli:</b>",$key);
        step('0');
        exit();
    }
}

if($data == "paytime"){
    if($cid == $umidjon){
        $key = json_encode(['inline_keyboard'=>[
            [['text'=>"✏️ Server sanasini o‘zgartirish",'callback_data'=>"changedate"]],
            [['text'=>$orqa,'callback_data'=>"devpanel"]]
        ]]);
        edit("📆 <b>$paytime</b> gacha to‘langan\n
⚙️ <b>Holat:</b> ".str_replace(["on","off"],["✅","❌"],determine($sana,$paytime))."\n
🗒️ <b>".sana($sana,$paytime)."</b> kundan keyin o‘chiriladi",$key);
        step('0');
        exit();
    }
}

if($data == "changedate"){
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>$orqa,'callback_data'=>"paytime"]]
    ]]);
    edit("📆 <b>Yangi sanani kiriting:</b>\n
<blockquote>Masalan: $sana</blockquote>",$key);
    step($data);
    exit();
}

if($step == "changedate"){
    put("set/paytime.txt",$text);
    bot('deleteMessage',[
        'chat_id'=>$cid,
        'message_id'=>$mid - 1]);
    delete();
    $key = json_encode(['inline_keyboard'=>[
        [['text'=>"✏️ Server sanasini o‘zgartirish",'callback_data'=>"changedate"]],
        [['text'=>$orqa,'callback_data'=>"devpanel"]]
    ]]);
    send("📆 <b>$text</b> sanasigacha to‘langan\n
⚙️ <b>Holat:</b> ".str_replace(["on","off"],["✅","❌"],determine($sana,$text))."\n
🗒️ <b>".sana($sana,$text)."</b> kundan keyin o‘chiriladi",$key);
    step('0');
    exit();
}

// Hech qanday matn yozilganda asosiy menyu chiqmasligi uchun bu qatorni o'chiramiz
// if (isset($message)) {
//     if ($type == "private" and joinchat($cid) == true) {
//         send($start, $menu);
//     }
// }

if($data == "topups" and joinchat($cid) == true) {
    $keyboard = [
        'inline_keyboard' => [
            [['icon_custom_emoji_id' => "5443139258267216193",'text' => " Uzcard Auto", 'callback_data' => "checkcard_pay"]],
            [['icon_custom_emoji_id' => "5927169041595634481",'text' => " Karta orqali to‘lov", 'callback_data' => "manual_pay"]],
            [['icon_custom_emoji_id' => "5442804194983554178",'text' => " Admin orqali to‘lov", 'url' => $admin_lk_url]],
            [['icon_custom_emoji_id' => "5278702045883292456",'text' => " Orqaga", 'callback_data' => "start"]]
        ]
    ];
    
    edit("<tg-emoji emoji-id=\"5443007523030312160\">👋</tg-emoji> <b>Hisobni to'ldirish</b>", json_encode($keyboard));
    exit();
}

if ($data == "checkcard_pay") {
    delete();
    $back = json_encode(['inline_keyboard' => [
        [['text' => $orqa, 'callback_data'=>"topups"]],
    ]]);
    send("<b><tg-emoji emoji-id=\"5278467510604160626\">👋</tg-emoji> Balansingizni necha so'mga to'ldirmoqchisiz?</b>\n\n<tg-emoji emoji-id=\"5440895910949181931\">👋</tg-emoji> <b>Minimal miqdor:</b> 1 000 so'm\n<tg-emoji emoji-id=\"5440895910949181931\">👋</tg-emoji> <b>Maksimal miqdor:</b> 10 000 000 so'm", $back);
    step("send_amount");
    exit();
}

if ($step == "send_amount" && $text != $orqa) {
    $amount = trim($text);
    
    if(!ctype_digit($amount)){
        send("<b>❌ Faqat raqamlardan foydalaning!</b>", null);
        step("0");
        exit;
    }
    
    $amount = (int)$amount;
    
    if($amount < 1000 || $amount > 10000000){
        send("<b>⬇️ Minimal:</b> 1 000 so'm\n<b>⬆️ Maksimal:</b> 10 000 000 so'm", $back);
        step("0");
        exit;
    }
    
    // API 2.0 bo'yicha WEB SAHIFALI to'lov yaratish (payurl=true)
    $api_url = "https://checkcard.uz/api?method=create&shop_id=" . urlencode($checkcard_shop_id) . "&shop_key=" . urlencode($checkcard_api_key) . "&amount=" . $amount . "&payurl=true";
    $response = file_get_contents($api_url);
    $response = json_decode($response, true);
    
    if(!$response){
        send("<b>⚠️ API bilan bog'lanishda xatolik!</b>", null);
        step("0");
        exit;
    }
    
    if($response['status'] === 'error'){
        send("<b>⚠️ " . $response['message'] . "</b>", null);
        step("0");
        exit;
    }
    
    if($response['status'] === 'success'){
        $order_code = $response['order'];
        $payurl = $response['payurl'];
        $card_number = $response['card'];
        $amount = $response['amount'];
        $time = $sana;
        
        // auto_payments jadvaliga qo'shish
        mysqli_query($connect, "INSERT INTO `auto_payments`(`user_id`, `amount`, `status`, `time`, `transaction_id`) 
                                VALUES ('{$cid}', '{$amount}', 'pending', '{$time}', '{$order_code}')");
        
        // WEB SAHIFALI TO'LOV HAVOLASI
        send("<b>✅ To'lov havolasi yaratildi!</b>\n\n🆔 Buyurtma ID: <code>$order_code</code>\n💵 Miqdori: " . number_format($amount, 0, '.', ' ') . " so'm\n💳 To'lov kartasi: <code>$card_number</code>\n⏰ Vaqt: 5 daqiqa ichida to'lang!\n\n👇 To'lov qilish uchun tugmani bosing:", 
        json_encode([
            'inline_keyboard' => [
                [['text' => "💳 To'lov qilish", 'url' => $payurl]],
                [['text' => "♻️ To'lovni tekshirish", 'callback_data' => "check_payment=$order_code"]],
                [['text' => "⛔️ Bekor qilish", 'callback_data' => "cancel_payment=$order_code"]],
                [['text' => $orqa, 'callback_data' => "topup"]]
            ]
        ]));
        
        step("0");
        exit();
    }
    
    step("0");
    exit();
}

// To'lovni tekshirish
if (stripos($data, "check_payment=") !== false) {
    $order_code = explode("=", $data)[1];
    
    $api_url = "https://checkcard.uz/api?method=check&order=" . urlencode($order_code);
    $response = file_get_contents($api_url);
    $result = json_decode($response, true);
    
    if (!$result || $result['status'] !== 'success') {
        ans("❌ Buyurtma topilmadi!");
        exit;
    }
    
    $order_data = $result['data'];
    $summa = (int)$order_data['amount'];
    $status = $order_data['status'];
    $sav = date("H:i:s | d.m.Y");
    
    mysqli_query($connect, "UPDATE auto_payments SET status='$status' WHERE transaction_id='$order_code'");
    
    if ($status === "paid") {
        mysqli_query($connect, "UPDATE auto_payments SET status='success', success_time='$sana' WHERE transaction_id='$order_code'");
        
        // Balansga qo'shish
        $new_balance = $pul + $summa;
        mysqli_query($connect, "UPDATE users SET money='$new_balance' WHERE user_id='$cid'");
        
        delete();
        send("<b>✅ Hisobingizga " . number_format($summa, 0, '.', ' ') . " so'm qo'shildi!</b>", $menu);
        
        // Adminlarga xabar
        $admins_query = mysqli_query($connect, "SELECT * FROM admins");
        while($xxx = mysqli_fetch_assoc($admins_query)){
            $admin_id = $xxx['user_id'];
            bot('sendMessage', [
                'chat_id' => $admin_id,
                'text' => "🎉 <b>Foydalanuvchi to'lov qildi!</b>\n\n👤 User: <a href='tg://user?id=$cid'>$name</a>\n💰 Balansi: " . number_format($new_balance, 0, '.', ' ') . " so'm\n💳 To'lov miqdori: " . number_format($summa, 0, '.', ' ') . " so'm\n🧾 Order: <code>$order_code</code>\n\n⏰ $sav",
                'parse_mode' => 'html'
            ]);
        }
        
    } elseif ($status === "cancel") {
        mysqli_query($connect, "UPDATE auto_payments SET status='cancel' WHERE transaction_id='$order_code'");
        delete();
        send("<b>❌ Sizning " . number_format($summa, 0, '.', ' ') . " so'mli to'lovingiz bekor qilindi!</b>", $menu);
        
    } elseif ($status === "pending") {
        ans("⏳ To'lov hali amalga oshirilmagan.\n\n💡 To'lovni web sahifada tugating!", true);
        
    } else {
        ans("⚠️ To'lov holati: <b>$status</b>");
    }
    exit();
}

// To'lovni bekor qilish
if (stripos($data, "cancel_payment=") !== false) {
    $order_code = explode("=", $data)[1];
    delete();
    
    $check = mysqli_fetch_assoc(mysqli_query($connect, "SELECT status FROM auto_payments WHERE transaction_id='$order_code'"));
    
    if ($check && $check['status'] !== 'success' && $check['status'] !== 'paid') {
        mysqli_query($connect, "UPDATE auto_payments SET status='cancel' WHERE transaction_id='$order_code'");
        
        // API orqali ham bekor qilish
        @file_get_contents("https://checkcard.uz/api?method=cancel&order=" . urlencode($order_code));
        
        send("<b>❌ To'lovingiz bekor qilindi!</b>", $menu);
    } else {
        send("<b>⚠️ Bu to'lov allaqachon qabul qilingan yoki mavjud emas!</b>", $menu);
    }
    exit();
}


if($data == "giftsho"){

    $gifts = [
        ['id'=>"5348275319168080470",'gift_id' => "5170233102089322756",'stars'=>15],
        ['id'=>"5348565014712195320",'gift_id' => "5170145012310081615",'stars'=>15],
        ['id'=>"5348068314629315530",'gift_id' => "5170250947678437525",'stars'=>25],
        ['id'=>"5348268919666809267",'gift_id' => "5168103777563050263",'stars'=>25],
        //['id'=>"5346220392065309034",'gift_id' => "5170233102089322756",'stars'=>50],
        ['id'=>"5346209104891255920",'gift_id' => "5170314324215857265",'stars'=>50],
        ['id'=>"5345913151579787927",'gift_id' => "5170564780938756245",'stars'=>50],
        //['id'=>"5348237669484761439",'gift_id' => "5170233102089322756",'stars'=>50],
        ['id'=>"5346192101115729092",'gift_id' => "5168043875654172773",'stars'=>100],
        ['id'=>"5346085770610380022",'gift_id' => "5170521118301225164",'stars'=>100],
        ['id'=>"5418194930025664422",'gift_id' => "5170690322832818290",'stars'=>100],
        //['id'=>"5379850840691476775",'gift_id' => "5170233102089322756",'stars'=>50],
        ['id'=>"5226661632259691727",'gift_id' => "5800655655995968830",'stars'=>50],
        ['id'=>"5289761157173775507",'gift_id' => "5866352046986232958",'stars'=>50],
        ['id'=>"5317000922096769303",'gift_id' => "5893356958802511476",'stars'=>50],
        //['id'=>"5359736160224586485",'gift_id' => "5170233102089322756",'stars'=>50],
        //['id'=>"5345935030143196497",'gift_id' => "5170233102089322756",'stars'=>50],
        ['id'=>"5345935030143196497",'gift_id' => "5922558454332916696",'stars'=>50],
        ['id'=>"5447213743417105726",'gift_id' => "6026193266406327981",'stars'=>50],
        ['id'=>"5393309541620291208",'gift_id' => "5969796561943660080",'stars'=>50],
        ['id'=>"5359736160224586485",'gift_id' => "5935895822435615975",'stars'=>50],
        ['id'=>"5289761157173775507",'gift_id' => "5866352046986232958",'stars'=>50],
        ['id'=>"5224628072619216265",'gift_id' => "5801108895304779062",'stars'=>50],
        ['id'=>"5379850840691476775",'gift_id' => "5956217000635139069",'stars'=>50],
    ];

    // PRIMARY style beriladigan gift_id lar ro'yxati
    $primary_gifts = [
        "5800655655995968830",
        "5866352046986232958", 
        "5893356958802511476",
        "5922558454332916696",
        "6026193266406327981",
        "5969796561943660080",
        "5935895822435615975",
        "5801108895304779062",
        "5956217000635139069"
    ];

    $keyboard = [];
    $row = [];

    foreach($gifts as $i => $gift){
        $price = $gift['stars'] * $star_price;
        $text_btn = number_format($price, 0, '.', ' ') . " so'm";
        
        // Agar gift_id primary_gifts ro'yxatida bo'lsa, style => primary qo'shiladi
        $button = [
            'text'=>$text_btn,
            'callback_data'=>"gifts=" . $gift['gift_id'],
            'icon_custom_emoji_id'=>$gift['id']
        ];
        
        if(in_array($gift['gift_id'], $primary_gifts)){
            $button['style'] = "primary";  // KO'K FON (faqat shu giftlar uchun)
        }
        
        $row[] = $button;
        
        if(count($row) == 2){
            $keyboard[] = $row;
            $row = [];
        }
    }
    if(!empty($row)){
        $keyboard[] = $row;
    }
    $keyboard[] = [['text'=>"Orqaga",'callback_data'=>"start",'icon_custom_emoji_id' => 5352759161945867747]];

    bot('editMessageText',[
        'chat_id'=>$cid,
        'message_id'=>$mid,
        'text'=>"<b><tg-emoji emoji-id='5938345530047337186'>🎁</tg-emoji> Telegram Gift xarid qilish

<blockquote><tg-emoji emoji-id='5316727448644103237'>👤</tg-emoji>  Giftni yuborish jarayoni @StazGoHelpprofili orqali anonim amalga oshiriladi

<tg-emoji emoji-id='5819095256267755019'>👤</tg-emoji>— Eksklyuziv</blockquote>

<tg-emoji emoji-id='5226513232549664618'>⏹️</tg-emoji> Iltimos, yuborish uchun kerakli Giftni tanlang</b>",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode(['inline_keyboard'=>$keyboard])
    ]);
}


if(mb_stripos($data, "gifts=") !== false){
    $jx = bot('editMessageText',[
        'message_id'=>$mid,
        'chat_id'=>$cid,
        'parse_mode'=>'html',
        'text'=>"<tg-emoji emoji-id=\"5877410604225924969\">🔄</tg-emoji> <b>Yuklanmoqda...</b>"
    ])->result->message_id;
    
    $gift_id = explode("=", $data)[1];
    
    $gifts_list = [
        ['id'=>"5348275319168080470", 'gift_id' => "5170233102089322756", 'stars'=>15, 'price'=>15 * $star_price, 'emoji_id'=>"5348275319168080470", 'name'=>"Kichik Gift"],
        ['id'=>"5348565014712195320", 'gift_id' => "5170145012310081615", 'stars'=>15, 'price'=>15 * $star_price, 'emoji_id'=>"5348565014712195320", 'name'=>"Oddiy Gift"],
        ['id'=>"5348068314629315530", 'gift_id' => "5170250947678437525", 'stars'=>25, 'price'=>25 * $star_price, 'emoji_id'=>"5348068314629315530", 'name'=>"O'rta Gift"],
        ['id'=>"5348268919666809267", 'gift_id' => "5168103777563050263", 'stars'=>25, 'price'=>25 * $star_price, 'emoji_id'=>"5348268919666809267", 'name'=>"Premium Gift"],
        ['id'=>"5346209104891255920", 'gift_id' => "5170314324215857265", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5346209104891255920", 'name'=>"VIP Gift"],
        ['id'=>"5345913151579787927", 'gift_id' => "5170564780938756245", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5345913151579787927", 'name'=>"Elite Gift"],
        ['id'=>"5346192101115729092", 'gift_id' => "5168043875654172773", 'stars'=>100, 'price'=>100 * $star_price, 'emoji_id'=>"5346192101115729092", 'name'=>"Royal Gift"],
        ['id'=>"5346085770610380022", 'gift_id' => "5170521118301225164", 'stars'=>100, 'price'=>100 * $star_price, 'emoji_id'=>"5346085770610380022", 'name'=>"Legend Gift"],
        ['id'=>"5418194930025664422", 'gift_id' => "5170690322832818290", 'stars'=>100, 'price'=>100 * $star_price, 'emoji_id'=>"5418194930025664422", 'name'=>"Ultimate Gift"],
        ['id'=>"5226661632259691727", 'gift_id' => "5800655655995968830", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5226661632259691727", 'name'=>"Maxsus Gift"],
        ['id'=>"5289761157173775507", 'gift_id' => "5866352046986232958", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5289761157173775507", 'name'=>"Eksklyuziv Gift"],
        ['id'=>"5317000922096769303", 'gift_id' => "5893356958802511476", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5317000922096769303", 'name'=>"Deluxe Gift"],
        ['id'=>"5345935030143196497", 'gift_id' => "5922558454332916696", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5345935030143196497", 'name'=>"Premium+ Gift"],
        ['id'=>"5447213743417105726", 'gift_id' => "6026193266406327981", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5447213743417105726", 'name'=>"Ultra Gift"],
        ['id'=>"5393309541620291208", 'gift_id' => "5969796561943660080", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5393309541620291208", 'name'=>"Mega Gift"],
        ['id'=>"5359736160224586485", 'gift_id' => "5935895822435615975", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5359736160224586485", 'name'=>"Giga Gift"],
        ['id'=>"5224628072619216265", 'gift_id' => "5801108895304779062", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5224628072619216265", 'name'=>"Tera Gift"],
        ['id'=>"5379850840691476775", 'gift_id' => "5956217000635139069", 'stars'=>50, 'price'=>50 * $star_price, 'emoji_id'=>"5379850840691476775", 'name'=>"Nova Gift"],
    ];
    
    $selected_gift = null;
    foreach($gifts_list as $gift){
        if($gift['gift_id'] == $gift_id){
            $selected_gift = $gift;
            break;
        }
    }
    
    if(!$selected_gift){
        bot('editMessageText',[
            'chat_id'=>$cid,
            'message_id'=>$jx,
            'parse_mode'=>'html',
            'text'=>"<b>❌ Gift topilmadi!</b>",
            'reply_markup'=>json_encode(['inline_keyboard'=>[
                [['text'=>$orqa,'callback_data'=>"giftsho"]]
            ]])
        ]);
        exit();
    }
    
    $temp_order = [
        'gift_id' => $selected_gift['gift_id'],
        'gift_name' => $selected_gift['name'],
        'stars' => $selected_gift['stars'],
        'price' => $selected_gift['price'],
        'emoji_id' => $selected_gift['emoji_id']
    ];
    save_temp_json('gift_order', $cid, $temp_order);
    
    $key = json_encode(['inline_keyboard' =>[
        [['icon_custom_emoji_id' => "6032608126480421344",'text'=>" O‘zimga","style"=> "primary",'callback_data'=>"gift_myself"]],
        [['text'=>$orqa,"style"=> "danger", 'callback_data'=> "giftsho"]]
    ]]);
    
    sleep(1);
    bot('editMessageText',[
        'chat_id'=>$cid,
        'message_id'=>$jx,
        'parse_mode'=>'html',
        'text'=>"<tg-emoji emoji-id='5771887475421090729'>👤</tg-emoji> <b>Gift qabul qiluvchi</b>\n\n"
            . "<blockquote><tg-emoji emoji-id='5879770735999717115'>🌀</tg-emoji> Giftni qaysi profilga yuborish kerak?\n\n"
            . "<tg-emoji emoji-id='5897658922600240288'>⭐️</tg-emoji> Narxi: <b>" . number_format($selected_gift['price'], 0, '.', ' ') . " so'm</b></blockquote>\n\n"
            . "<tg-emoji emoji-id='5879841310902324730'>✏️</tg-emoji> Kerakli usernameni yuboring yoki tugmani bosing:",
        'reply_markup'=>$key
    ]);
    exit();
}

if($data == "gift_myself"){
    $temp = load_temp_json('gift_order', $cid);
    if(empty($temp)){
        ans("❌ Xatolik! Iltimos, qaytadan gift tanlang.");
        exit();
    }
    
    $temp['receiver'] = $cid;
    $temp['receiver_type'] = 'self';
    save_temp_json('gift_order', $cid, $temp);
    
    $price = number_format($temp['price'], 0, '.', ' ');
    $key = json_encode(['inline_keyboard' =>[
        [['text'=>"💵 Sotib olish ($price soʻm)",'callback_data'=>"gift_purchase"]],
        [['text'=>$orqa, 'callback_data'=>"giftsho"]]
    ]]);
    
    edit("<b>🛒 Gift buyurtma tayyor!</b>\n\n"
        . "<tg-emoji emoji-id='5472401690793614752'>💶</tg-emoji> Narxi: $price so'm\n"
        . "<tg-emoji emoji-id='5771887475421090729'>👤</tg-emoji> Qabul qiluvchi: @$username\n\n"
        . "<b>Sotib olish uchun bosing:</b>", $key);
    exit();
}

if(isset($text) && mb_stripos($step, "") !== false && file_exists("step/$cid.txt")){
    $step_file = file_get_contents("step/$cid.txt");
    if(mb_stripos($step_file, "gift_") !== false){
        $temp = load_temp_json('gift_order', $cid);
        if(empty($temp)){
            send("<b>❌ Xatolik! Iltimos, qaytadan gift tanlang.</b>", $menu);
            step("0");
            exit();
        }
        
        $username = clean_username($text);
        if($username != null){
            $temp['receiver'] = "$cid";
            $temp['receiver_type'] = 'username';
            save_temp_json('gift_order', $cid, $temp);
            
            $price = number_format($temp['price'], 0, '.', ' ');
            $key = json_encode(['inline_keyboard' =>[
                [['text'=>"💵 Sotib olish ($price soʻm)",'callback_data'=>"gift_purchase"]],
                [['text'=>$orqa, 'callback_data'=>"giftsho"]]
            ]]);
            
            send("<b>🛒 Gift buyurtma tayyor!</b>\n\n"
                . "<tg-emoji emoji-id='5472401690793614752'>💶</tg-emoji> Narxi: $price so'm\n"
                . "<tg-emoji emoji-id='5771887475421090729'>👤</tg-emoji> Qabul qiluvchi: @$username\n\n"
                . "<b>Sotib olish uchun bosing:</b>", $key);
            
            @unlink("step/$cid.txt");
            step("0");
            exit();
        } else {
            send("<b>❌ Noto'g'ri username!</b>\n\nIltimos, to'g'ri usernameni kiriting (masalan: @username)", $menu);
            step("0");
            exit();
        }
    }
}

if($data == "gift_purchase"){
    $temp = load_temp_json('gift_order', $cid);
    if(empty($temp)){
        ans("❌ Xatolik! Iltimos, qaytadan gift tanlang.");
        exit();
    }
    
    $price = $temp['price'];
    $stars = $temp['stars'];
    $gift_id = $temp['gift_id'];
    $receiver = $temp['receiver'];
    
    if($pul >= $price){

        
        delete();
        
        $send_gift_result = send_gift_via_bot($gift_id, $receiver);
        
        if($send_gift_result['ok']){
            $new_balance = $pul - $price;
            mysqli_query($connect, "UPDATE users SET money = '$new_balance' WHERE user_id = '$cid'");
            
            $order_id = time() . rand(100, 999);
            $order_file = "gift_orders/$order_id.json";
            $order_data = [
                'order_id' => $order_id,
                'user_id' => $cid,
                'user_name' => $name,
                'gift_id' => $gift_id,
                'gift_name' => $temp['gift_name'],
                'stars' => $stars,
                'price' => $price,
                'receiver' => $receiver,
                'status' => 'completed',
                'date' => $sana,
                'time' => $time
            ];
            file_put_contents($order_file, json_encode($order_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            send("<b>✅ Gift muvaffaqiyatli yuborildi!</b>\n\n"
                . "<tg-emoji emoji-id='5897658922600240288'>⭐️</tg-emoji> Stars: $stars ta\n"
                . "<tg-emoji emoji-id='5771887475421090729'>👤</tg-emoji> Qabul qiluvchi: $receiver\n\n"
                . "Foydalanganingiz uchun rahmat!", $menu);
            

            
            clear_temp_json('gift_order', $cid);
            exit();
        } else {
            send("<b>❌ Gift yuborishda xatolik!</b>\n\n" . ($send_gift_result['error'] ?? "Iltimos, qaytadan urinib ko'ring"), $menu);
            clear_temp_json('gift_order', $cid);
            exit();
        }
    } else {
        $key = json_encode(['inline_keyboard' => [
            [['text' => "💵 Hisobni to'ldirish", 'callback_data'=>"topups"]],
            [['text' => $orqa, 'callback_data'=>"giftsho"]]
        ]]);
        edit("<b>❌ Hisobingizda mablag' yetarli emas!</b>\n\n"
            . "💰 Sizning balansingiz: " . number_format($pul, 0, '.', ' ') . " so'm\n"
            . "💵 Gift narxi: " . number_format($price, 0, '.', ' ') . " so'm\n\n"
            . "Iltimos, avval hisobingizni to'ldiring!", $key);
        clear_temp_json('gift_order', $cid);
        exit();
    }
}

function send_gift_via_bot($gift_id, $receiver){
    $balance_url = "https://ws1925.wineclo.com/api_zak/?action=balance";
    $balance_response = file_get_contents($balance_url);
    $balance_data = json_decode($balance_response, true);
    
    if(!$balance_data['ok']){
        return ['ok' => false, 'error' => "Balansni tekshirib bo'lmadi"];
    }
    
    if($balance_data['balance'] <= 0){
        return ['ok' => false, 'error' => "Bot balansida yetarli mablag' mavjud emas"];
    }
    
    $send_url = "https://ws1925.wineclo.com/api_zak/?action=send&user=" . urlencode($receiver) . "&id=" . urlencode($gift_id);
    $send_response = file_get_contents($send_url);
    $send_data = json_decode($send_response, true);
    
    if($send_data['ok']){
        return ['ok' => true];
    } else {
        return ['ok' => false, 'error' => "Gift yuborish amalga oshmadi"];
    }
}

if($data == "support" and joinchat($cid) == true){
    $ort = json_encode(['inline_keyboard' => [
        [['text' => "🔙 Orqaga", 'callback_data' => "start"]]
    ]]);
    
    send("<blockquote><tg-emoji emoji-id='5438591725419389858'>🌟</tg-emoji> Yangiliklar kanalimiz: \n@stazgouz\n\n<tg-emoji emoji-id='5472201536727686043'>🌟</tg-emoji> Qoʻllab quvvatlash:\n @StazGoHelp\n\n<tg-emoji emoji-id='5994297722574737553'>🌟</tg-emoji> Savol va takliflaringizni boʻlsa yozib qoldiring!</blockquote>", $ort);
    
    step("murojaat");
}

if($step == "murojaat" and isset($text)){
    $m = json_encode(['inline_keyboard' => [
        [['text' => "🔙 Orqaga", 'callback_data' => "start"]]
    ]]);
    
    send("<b><tg-emoji emoji-id='5438279988103109482'>🌟</tg-emoji>  Murojaatingiz qabul qilindi!\n\n<tg-emoji emoji-id='5274099962655816924'>🌟</tg-emoji> Iltimos admin javobini kuting.</b>", $m);
    
    bot('copyMessage', [
        'chat_id' => $admin,
        'from_chat_id' => $cid,
        'message_id' => $mid,
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => "👁️ Ko‘rish", 'url' => "tg://user?id=$cid"]],
                [['text' => "📑 Javob yozish", 'callback_data' => "javob=$cid"]]
            ]
        ])
    ]);
    
    step("0");
}

if(stripos($data, "javob=") !== false){
    $ida = explode("=", $data)[1];
    $ort = json_encode(['inline_keyboard' => [
        [['text' => "🔙 Orqaga", 'callback_data' => "panel"]]
    ]]);
    
    send("<b>$ida Foydalanuvchiga yuboriladigan xabaringizni kiriting.</b>", $ort);
    
    step("ticket=$ida");
}

if(mb_stripos($step, "ticket=") !== false and $admins){
    $ida = explode("=", $step)[1];
    
    $if = bot('copyMessage', [
        'chat_id' => $ida,
        'from_chat_id' => $cid,
        'message_id' => $mid,
    ]);
    
    if($if->ok == 1){
        send("<i>✅ Xabar yuborildi</i>", $panel);
    } else {
        send("❌ Xabar yuborilmadi, ehtimol botni bloklagan.", $panel);
    }
    
    step("0");
}


?>