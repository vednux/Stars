-- Database jadvallari
CREATE TABLE IF NOT EXISTS `users` (
    `id` int(50) auto_increment primary key,
    `user_id` varchar(500),
    `username` varchar(255),
    `date` varchar(500),
    `step` varchar(500),
    `status` varchar(500),
    `ban` varchar(500),
    `money` varchar(500),
    `ref` varchar(500),
    `refid` varchar(500)
);

CREATE TABLE IF NOT EXISTS `admins` (
    `id` int(50) auto_increment primary key,
    `user_id` varchar(500)
);

CREATE TABLE IF NOT EXISTS `cheques` (
    `id` int(50) auto_increment primary key,
    `cheque` varchar(500),
    `money` varchar(500),
    `status` varchar(500),
    `user` varchar(500)
);

CREATE TABLE IF NOT EXISTS `send` (
    id int(20) auto_increment primary key,
    time1 varchar(100),
    time2 varchar(100),
    time3 varchar(100),
    time4 varchar(100),
    time5 varchar(100),
    start_id varchar(100),
    stop_id varchar(100),
    admin_id varchar(100),
    message_id varchar(100),
    reply_markup varchar(100),
    step varchar(100)
);

CREATE TABLE IF NOT EXISTS `orders` (
    `id` int(50) auto_increment primary key,
    `order_id` varchar(500),
    `user_id` varchar(500),
    `stars` varchar(1000),
    `status` varchar(1000),
    `price` varchar(1000),
    `priceton` varchar(1000),
    `username` varchar(1000),
    `time` varchar(1000)
);

CREATE TABLE IF NOT EXISTS `premium` (
    `id` int(50) auto_increment primary key,
    `order_id` varchar(500),
    `user_id` varchar(500),
    `month` varchar(1000),
    `status` varchar(1000),
    `price` varchar(1000),
    `username` varchar(1000),
    `time` varchar(1000)
);

CREATE TABLE IF NOT EXISTS `auto_payments` (
    `id` int(20) auto_increment primary key,
    `user_id` varchar(256),
    `amount` varchar(256),
    `status` varchar(256),
    `time` varchar(256),
    `success_time` varchar(256),
    `transaction_id` varchar(500),
    `payment_url` text
);

CREATE TABLE IF NOT EXISTS `manual_payment_cards` (
    `id` int(20) auto_increment primary key,
    `card_number` varchar(64),
    `owner` varchar(255),
    `note` text,
    `status` varchar(32) default 'active',
    `created_at` varchar(64)
);

CREATE TABLE IF NOT EXISTS `manual_payments` (
    `id` int(20) auto_increment primary key,
    `user_id` varchar(256),
    `card_id` int(20),
    `amount` varchar(256),
    `status` varchar(32),
    `proof_chat_id` varchar(256),
    `proof_message_id` varchar(256),
    `admin_id` varchar(256),
    `admin_messages` text,
    `created_at` varchar(64),
    `checked_at` varchar(64)
);

CREATE TABLE IF NOT EXISTS `bot_star_topups` (
    `id` int(20) auto_increment primary key,
    `admin_id` varchar(256),
    `amount` varchar(256),
    `status` varchar(32),
    `payload` varchar(256),
    `created_at` varchar(64),
    `paid_at` varchar(64),
    `charge_id` varchar(500)
);
